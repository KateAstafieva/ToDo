require('coffee-script');
require('./src/cluster');