#!/bin/bash

confs_folder=/home/ubuntu/apache-configs
first=$confs_folder'/first'
second=$confs_folder'/second'
site_name='ec2-50-16-117-133.compute-1.amazonaws.com'
config=$1


for file in $confs_folder/active/*
do
    if [ -f $file ]; then
        echo "Current config file: "$file 
        rm -f $file
	if [ $(basename $file) = $(basename $second) ] 
        then
            echo "Replacing old config with: "$first
            cp $first $confs_folder/active/$(basename $first)
	    cp $first /etc/apache2/sites-available/$site_name        
        else
            echo "Replacing old config with: "$second
            cp $second $confs_folder/active/$(basename $second)
            cp $second /etc/apache2/sites-available/$site_name
        fi 
    break
    fi
done

/etc/init.d/apache2 restart
