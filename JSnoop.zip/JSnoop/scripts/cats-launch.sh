#!/bin/sh

first_cat_base=/var/lib/tomcat6
second_cat_base=/var/lib/tomcat6b
start_script="/usr/share/tomcat6/bin/catalina.sh"


#kill all tomcats
ps ax | grep tomcat | while read -r process
do
    pid=`echo $process|awk {'print $1'}`
    kill $pid
done

#start first tomcat instance
export CATALINA_BASE=$first_cat_base

run="sudo -E sh $start_script start"
$run

#start second tomcat instance
export CATALINA_BASE=$second_cat_base

run="sudo -E sh $start_script start"
$run

