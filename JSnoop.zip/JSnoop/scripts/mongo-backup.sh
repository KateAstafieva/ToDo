#!/bin/bash

MONGO='/usr/bin/mongo'
MONGO_DUMP='/usr/bin/mongodump'
S3='/usr/bin/s3cmd'


host_name=$1
db_name=$2

date_now=`date +%Y_%m_%d_%H_%M_%S`
dir_name=${db_name}'_backup_'${date_now}
file_name=${db_name}'_backup_'${date_now}'.bz2'


log(){
   echo $1
}


backup(){
   log "Starting backup of "${db_name}" database..." && \
   ${MONGO}  ${host_name}/${db_name} --eval "db.fsyncLock()" && \
   log "DB locked." && \
   log "Dumping..." && \
   ${MONGO_DUMP} -h ${host_name} -d ${db_name} -o ${dir_name} && \
   tar -jcf ${file_name} ${dir_name} && \
   
   log "Dump complete." && \
   ${MONGO}  ${host_name}/${db_name} --eval "db.fsyncUnlock()" && \
   log "DB unlocked" && \
   log "Backup finished."
}

store(){
   log "Uploading to amazone S3..." && \
   
   deleteOld && \
   ${S3} put ${file_name} s3://JSnoop/mongodumps/ && \
   log "Upload complete."   
}

deleteOld(){
   log "Removing old dumps" && \

   now_date=`date -d "now" +%s`
   big_date_range=$((20*24*60*60))
   small_date_range=$((9*24*60*60))
   big_store_date=0
   
   ${S3} ls s3://JSnoop/mongodumps/ | while read -r dump_file  
      do        

         dump_upload_date=`echo ${dump_file}|awk {'print $1" "$2'}`    
         dump_upload_date=`date -d "${dump_upload_date}" +%s`

         if [ ${big_store_date} -gt 0 -a  $((${dump_upload_date}-${big_store_date})) -lt ${small_date_range} ] 
         then               
             fileName=`echo ${dump_file}|awk {'print $4'}`
             ${S3} del "$fileName"             
         fi 
         
         
         if [ $((${now_date}-${dump_upload_date})) -lt ${big_date_range} -a $((${now_date}-${dump_upload_date})) -gt ${small_date_range} ] 
         then            
            big_store_date=${dump_upload_date}
            continue
         fi    
         
      done
   log "Done."
}

cleanup(){
   log "Cleaning up the mess..." && \
   rm -rf ${dir_name}* && \
   log "All done." 
}


backup && store && cleanup

