#!/bin/bash

MONGO='/usr/bin/mongo'
MONGO_RESTORE='/usr/bin/mongorestore'
S3='/usr/bin/s3cmd'

host_name=$1
db_name=$2
s3_path=$3


log(){
   echo $1
}


restore(){
   log "Downloading backup archive from "${s3_path}" ..." && \
   ${S3} get ${s3_path} && \
   file_name=$(basename ${s3_path}) && \
   log "Restoring "${db_name}" database from "${file_name}" archive..." && \   
   tar -jxf ${file_name} && \   
   ${MONGO_RESTORE} -h ${host_name} -d ${db_name} ${file_name%.*}/${db_name} && \
     
   log "Restore complete."
   
}


cleanup(){
   log "Cleaning up the mess..." && \
   rm -rf $(basename ${s3_path%.*})* && \
   log "All done." 
}

restore && cleanup
