define([
    'jquery',
    'underscore',
    'baseview',
    'collections/applications',
    'views/application/main',
    'views/application/add',
    'text!templates/application/main.html',
    'text!templates/application/list.html',
    'text!templates/application/addOption.html'
], function($, _, BaseView, Applications, ApplicationView, ApplicationAddView, appViewTemplate,  appsListTemplate, addOptionTemplate){

    var AppsView = BaseView.extend({
        el: $("#mainView"),

        initialize: function(options) {

            // fetch collection apps collection from the server
            this.collection = new Applications();
            var fetchUrl = "/apps/list/"+userId;
            this.collection.fetch({url: fetchUrl, async: false, cache: false});

        },

        events: {
            "appAdd" : "addApp",
            "appDelete": "deleteApp"
        },

        render: function(){
            var template = _.template($(appsListTemplate).html());
            this.$el.html(template);

            // add each app from the collection to the apps container within loaded template
            this.appsContainer = this.$(".apps");
            this.noAppsMessage = this.$(".noapps");

            var that = this;

            // if no apps
            if (this.collection.length == 0) {
                this.$(".noapps").removeClass("hidden");
            } else {
                _.each(this.collection.models, function(app){
                    var application = new ApplicationView({model: app});
                    that.appsContainer.append(application.render(appViewTemplate).el);
                }, this);
            }

            // render application add option below
            var addView = new ApplicationAddView();
            this.$(".addOption").append(addView.render(addOptionTemplate).el);
        },

        // add new application view to the list
        addApp: function(e, app) {

            // add to the collection
            this.collection.add(app);

            // render app view
            var appView = new ApplicationView({model: app});
            this.appsContainer.append(appView.render(appViewTemplate).el);
            this.noAppsMessage.addClass("hidden");
        },

        // remove app from the collection
        deleteApp: function(e, app) {
            this.collection.remove(app, {silent: true});

            var deleteUrl = "/apps/delete/"+ userId + "/" + app.get("appId");
            app.destroy({url: deleteUrl});

            if(this.collection.length == 0) {
                this.noAppsMessage.removeClass("hidden");
            }
        }
    });

    return AppsView;
});
