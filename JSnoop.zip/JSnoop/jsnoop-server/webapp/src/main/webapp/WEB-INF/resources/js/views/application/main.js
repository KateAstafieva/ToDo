define([
    'jquery',
    'underscore',
    'backbone',
    'text!templates/application/main.html',
    'text!templates/application/edit.html'
], function ($, _, Backbone, viewTemplate, editTemplate) {

    var ApplicationView = Backbone.View.extend({

        render:function (template) {
            this.model.initializeAccess(userEmail);
            var template = _.template($(template).html(), this.model.toJSON());
            this.$el.html(template);
            this.input = this.$("#edit");
            this.shareDialog = this.$(".share-dialog");
            this.email = this.$("input.email-share");
            return this;
        },

        events: {
            "dblclick #name":"edit",
            "click #save":"saveChanges",
            "click #cancel":"cancelChanges",
            "click .delete":"deleteApp",
            "click .share":"shareApp",
            "click .share-btn":"showShareDialog"
        },

        // render edit template
        edit:function () {
            this.render(editTemplate);
            this.input.focus();
        },

        // save changes after app edit
        saveChanges:function () {

            // store old app name
            this.options.oldAppName = this.model.get("name");
            var newName = this.input.val();

            // if name does not match regex or absent
            if (! newName || !newName.match(this.NAME_RULE)) {
                this.input.focus();
                return;
            }

            // if name have not changed then just cancel editing
            if (this.options.oldAppName === newName) {
                this.cancelChanges();
                return;
            }

            // else - save changes
            var appToEdit = {
                name:newName,
                appId:this.model.get("appId")
            };

            $.ajax({
                type:'POST',
                url:"/apps/edit/" + userId,
                data:appToEdit,
                dataType:'json',
                success:this.saveSuccess,
                error:this.saveError
            });

            this.model.set({name:newName});
        },

        // handle save action success response from the server
        saveSuccess:function (response) {
            if (!response) {
                alert("Application with that name already exists");
                this.model.set({name:this.options.oldAppName});
            } else {
                this.cancelChanges();
            }
        },

        saveError:function (response) {
            this.model.set({name:this.options.oldAppName});
        },

        cancelChanges:function () {
            this.render(viewTemplate);
        },

        deleteApp:function () {
            var appToDelete = this.model;
            this.$el.trigger("appDelete", appToDelete);
            this.remove();
        },

        showShareDialog: function(){
            this.shareDialog.modal("show");
        },

        shareApp:function () {

            var email = this.email.val();
            var access = this.$("select.access-share").val();

            if (!email.match(this.EMAIL_RULE)) {
                this.email.focus();
                return;
            } else {
                var data = "appId=" + this.model.get("appId") + "&email=" + email + "&access=" + access;
                var url = "/apps/share/" + userId;
                $.post(url, data);
                this.shareDialog.modal("hide");
            }

        },

        initialize:function () {
            _.bindAll(this, 'saveSuccess', 'saveError');
            this.NAME_RULE = /^[A-Za-z0-9\-\ \_]{0,}$/;
            this.EMAIL_RULE = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
        }
    });

    return ApplicationView;
});
