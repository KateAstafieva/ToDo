define([
    'jquery',
    'underscore',
    'views/application/chart/baseChart',
    'text!templates/application/graph.html'
], function ($, _, BaseChart, graphViewTemplate) {

    var SimpleChart = BaseChart.extend({

        el:$("#mainView"),

        initialize:function (options) {
            _.bindAll(this,
                "createChartModel",
                "setCurrentMinDate",
                "setCurrentMaxDate",
                "fromDatepickerSelect",
                "toDatepickerSelect",
                "fromDatePickerClose",
                "toDatepickerClose",
                "zoomHandler",
                "panHandler",
                "fromHoursShowCallback",
                "toHoursShowCallback",
                "fromTimeSelect",
                "toTimeSelect",
                "handleMouseWheel");

            this.appInfo = this.getAppInfo(this.options.appId);
            this.TIME_GAP = 1000;    // one second between timestamps on graph
        },

        events:{
            "change .graph-show-checkbox":"changeGraphVisibility",
            "click a.remove-from":"removeFromClearFilter",
            "click a.remove-to":"removeToClearFilter"
        },

        // fetch data about reports activity for this application
        getAppInfo:function (appId) {
            var appInfo = {};
            var fetchUrl ="/report/chart/" + userId + "/" + appId;
            $.ajax({
                url:fetchUrl,
                async:false,
                success:function (response) {
                    appInfo = JSON.parse(response);
                }
            });

            return appInfo;
        },

        render:function () {
            var template = _.template($(graphViewTemplate).html(), this.appInfo);
            this.$el.html(template);

            this.legend = this.$(".graph-legend").get(0);
            this.graph = this.$(".graph");
            this.settings = this.$(".settings");
            this.toDate = this.$(".to-date");
            this.fromDate = this.$(".from-date");
            this.toTime = this.$(".to-time");
            this.fromTime = this.$(".from-time");

            if (this.thereAreNoReports()) {
                this.showNoReportsMessage();
                return;
            }

            this.renderGraph();
            this.bindMouseWheelHandler();
            this.initializeDatePickers();
        },

        bindMouseWheelHandler: function(){
            this.graph.mousewheel(this.handleMouseWheel);
        },

        renderGraph:function () {

            // parse collection and create model for Dygraph lib
            var data = this.initializeTimeGaps(this.appInfo);
            var parsedData = this.parseData(data);
            var model = this.createChartModel(parsedData);
            this.g = new Dygraph(
                this.graph.get(0),
                model,
                {
                    //zoomCallback: this.zoomHandler,
                    // drawCallback: this.panHandler,
                    height:350,
                    labelsDiv:this.legend,
                    animatedZooms:false,
                    connectSeparatedPoints: true,
                    xAxisLabelWidth:60,
                    axes:{
                        x:{
                            pixelsPerLabel:100
                        }
                    }
                }
            );
        },

        // handle graph zoom
        zoomHandler:function () {
            //this.toDate.datepicker("setDate", new Date(this.getCurrentMaxDate()));
            //this.fromDate.datepicker("setDate", new Date(this.getCurrentMinDate()));
        },

        // handle graph pan
        panHandler:function (g) {
            // something...
        },

        handleMouseWheel: function(e, delta){

            var modifiers = this.calculateZoomModifiers(e);

            // scroll up
            if(delta > 0){
                this.zoomIn(0.05, modifiers.min, modifiers.max);
            }
            // scroll down
            else if (delta<0){
                this.zoomOut(0.05, modifiers.min, modifiers.max);
            }
        },

        thereAreNoReports:function () {
            return this.appInfo.details.length < 1;
        },

        showNoReportsMessage:function () {
            this.graph.text("There are no reports for selected applications.");
        },


        fromDatepickerSelect:function (date) {

            var datetimeString = date + " " + this.fromTime.val();
            date = new Date(datetimeString);

            var fiveMinutes = 300000;
            if (date.getTime() > this.getCurrentMaxDate()) {
                date = new Date(this.getCurrentMaxDate() - fiveMinutes);
                this.fromTime.timepicker("setTime", date.getHours() + ":" + date.getMinutes());
            }

            this.toDate.datepicker("option", {minDate:date});
            this.setCurrentMinDate(date.getTime());
        },

        toDatepickerSelect:function (date) {
            var datetimeString = date + " " + this.toTime.val();
            date = new Date(datetimeString);

            var fiveMinutes = 300000;
            if (date.getTime() < this.getCurrentMinDate()) {
                date = new Date(this.getCurrentMinDate() + fiveMinutes);
                this.toTime.timepicker("setTime", date.getHours() + ":" + date.getMinutes());
            }

            this.fromDate.datepicker("option", {maxDate:date});
            this.setCurrentMaxDate(date.getTime());
        },

        fromTimeSelect:function (time) {
            var datetimeString = this.fromDate.val() + " " + time;
            var date = new Date(datetimeString);

            this.toDate.datepicker("option", {minDate:date});
            this.setCurrentMinDate(date.getTime());
        },

        toTimeSelect:function (time) {
            var datetimeString = this.toDate.val() + " " + time;
            var date = new Date(datetimeString);

            this.fromDate.datepicker("option", {maxDate:date});
            this.setCurrentMaxDate(date.getTime());
        },

        fromDatePickerClose:function () {
            if (!this.fromDate.val()) {
                this.removeFromClearFilter();
            }
        },

        toDatepickerClose:function () {
            if (!this.toDate.val()) {
                this.removeToClearFilter();
            }
        },

        // setup delete filter range datepickers
        initializeDatePickers:function () {
            var maxDate = new Date(this.getMaxDate());
            var minDate = new Date(this.getMinDate());
            var that = this;

            this.fromDate.datepicker({
                onSelect:that.fromDatepickerSelect,
                onClose:that.fromDatePickerClose,
                maxDate:maxDate,
                minDate:minDate
            }).datepicker("setDate", minDate);

            this.toDate.datepicker({
                onSelect:that.toDatepickerSelect,
                onClose:that.toDatepickerClose,
                maxDate:maxDate,
                minDate:minDate
            }).datepicker("setDate", maxDate);

            this.toTime.timepicker({
                showCloseButton:true,
                onHourShow:that.toHoursShowCallback,
                onSelect:that.toTimeSelect
            });

            this.fromTime.timepicker({
                showCloseButton:true,
                onHourShow:that.fromHoursShowCallback,
                onSelect:that.fromTimeSelect
            });
        },

        fromHoursShowCallback:function (hour) {

            var currentDate = this.fromDate.datepicker("getDate");
            var maxDate = this.toDate.datepicker("getDate");

            var maxDay = maxDate.getFullYear() == currentDate.getFullYear() &&
                maxDate.getMonth() == currentDate.getMonth() &&
                maxDate.getDate() == currentDate.getDate();

            return !maxDay || maxDay && (this.toTime.val() == "" || this.toTime.timepicker("getHour") > hour );

        },
        toHoursShowCallback:function (hour) {

            var minDate = this.fromDate.datepicker("getDate");
            var currentDate = this.toDate.datepicker("getDate");

            var minDay = minDate.getFullYear() == currentDate.getFullYear() &&
                minDate.getMonth() == currentDate.getMonth() &&
                minDate.getDate() == currentDate.getDate();

            return !minDay || minDay && (this.fromTime.val() == "" || this.fromTime.timepicker("getHour") < hour);


        },

        // clear value of "toDate" datepicker of clear filter
        removeToClearFilter:function () {
            this.toTime.val("");
            this.toDate.datepicker("setDate", new Date(this.getMaxDate()));
            this.fromDate.datepicker("option", {maxDate:new Date(this.getMaxDate())});
            this.resetCurrentMaxDate();
        },


        // clear value of "fromDate" datepicker of clear filter
        removeFromClearFilter:function () {
            this.fromTime.val("");
            this.fromDate.datepicker("setDate", new Date(this.getMinDate()));
            this.toDate.datepicker("option", {minDate:new Date(this.getMinDate())});
            this.resetCurrentMinDate();
        },

        changeGraphVisibility:function (e) {
            var changedCheckbox = $(e.target);

            var graphIndex = changedCheckbox.data("graph-index");
            var visible = changedCheckbox.attr("checked") == "checked" ? 1 : 0;

            this.g.setVisibility(graphIndex, visible);
        }

    });
    return SimpleChart;
});

