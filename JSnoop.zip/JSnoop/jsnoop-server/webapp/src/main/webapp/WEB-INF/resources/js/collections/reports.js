define([
    'jquery',
    'underscore',
    'backbone',
    'models/report'
], function($, _, Backbone, Report){

    var Reports = Backbone.Collection.extend({
        model: Report
    });

    return Reports;
});
