define([
    'jquery',
    'underscore',
    'backbone'
], function($, _, Backbone){

    var Report = Backbone.Model.extend({
        defaults: {
            id: "",
            userId: "",
            appId: "",
            type: "",
            tags: [],
            message: "",
            details: {
                mode: "",
                message: "",
                stack: []
            },
            extras: ""
        }
    });

    return Report;
});




