define([
    'jquery',
    'underscore',
    'baseview',
    'jqGrid',
    "models/application",
    'models/report',
    'views/report/main',
    'text!templates/report/main.html',
    'text!templates/report/table.html'
], function ($, _, BaseView, jqGrid, Application, Report, ReportView, reportTemplate, reportsTableTemplate) {

    var ReportsView = BaseView.extend({
        el:$("#mainView"),

        initialize:function (options) {
            _.bindAll(this,
                "render",
                "showReportDetails",
                "showReportsTable",
                "checkUpdates",
                "getUpdateCheckData",
                "getSelectedTags",
                "getFilterMessage");

            this.appId = options.appId;
            this.application = this.fetchApp(this.appId);
            this.tagList = [];
            this.addedTags = [];
            this.selectedTags = [];
        },

        events:{
            "click a.tag":"addTag",
            "click a.delete-confirm":"deleteReports",
            "click a.search":"refreshTable",
            "dblclick .tag-added":"removeTag",
            "click a.refresh":"refreshView",
            "click a.remove-from":"removeFromClearFilter",
            "click a.remove-to":"removeToClearFilter",
            "click .reports-view-mode-tab":"showReportsTable"
        },


        // render reports from specified page
        render:function () {
            var template = _.template($(reportsTableTemplate).html(), this.application.toJSON());
            this.$el.html(template);

            // cache dom components
            this.reportsView = this.$(".reports-view");
            this.tagsContainer = this.$(".tags-container");
            this.tagsDropDown = this.$(".tags");
            this.detailsContainer = this.$(".details");
            this.noReportsMessage = this.$(".no-reports-message");
            this.reportsTable = this.$("table#reports-table");
            this.toDate = this.$(".to-date");
            this.fromDate = this.$(".from-date");
            this.filterTagsContainer = this.$(".filter-tag-list");
            this.realtimeTable = this.$("table#reports-table-realtime");
            this.filterMessage = this.$(".filter-message");


            if (!this.reportsExists()) {
                this.showNoReportsMessage();
                return this;
            }


            // setup and render ui
            this.renderTagList();
            this.renderTable();
            this.renderTooltips();
            this.initializeDatePickers();
            this.showReportsView();

        },

        fetchApp:function (appId) {
            var application = new Application({url: fetchUrl});
            var fetchUrl = "/apps/get/" + userId + "/" + this.appId;
            application.fetch({url:fetchUrl, silent:true, async:false});
            application.initializeAccess(userEmail);
            return application;
        },

        // this methow will be invoked by the router on the view unloading         
        dispose:function () {

            // stop realtime updating if it is hadn`t stoped
            clearInterval(this.updatesInterval);

            // call baseview dispose method
            BaseView.prototype.dispose.call(this);
        },

        // check if application has any reports
        reportsExists:function () {
            var reportsExists = false;
            var reportsCheckUrl = "/report/hasReports/" + userId + "/" + this.appId;

            $.ajax({
                url:reportsCheckUrl,
                async:false,
                success:function (result) {
                    reportsExists = result;
                }
            });
            return reportsExists;
        },

        // renders common table with pagination, sorting etc.
        renderTable:function () {
            var pager = this.$("#pager");
            var url = '/report/list/' + userId + '/' + this.appId;
            var that = this;

            this.reportsTable.jqGrid(
                {
                    url:url,
                    datatype:'json',
                    gridview:true,
                    colNames:[
                        'Report message',
                        'Date',
                        'Tags',
                        'id',
                        'appId',
                        'userId'],

                    colModel:[
                        {name:'message', index:'message', width:400},
                        {
                            name:'date',
                            index:'date',
                            width:180,
                            formatter:function (cellValue, options) {
                                if (cellValue) {
                                    return $.fmatter.util.DateFormat(
                                        '',
                                        new Date(+cellValue),
                                        'Y/m/d H:i:s.u',
                                        $.extend({}, $.jgrid.formatter.date, options)
                                    );
                                } else {
                                    return '';
                                }
                            }
                        },
                        {name:'tags', width:200, sortable:false},
                        {name:'id', hidden:true},
                        {name:'appId', hidden:true},
                        {name:'userId', hidden:true}
                    ],
                    rowNum:20,
                    loadonce:false,
                    rownumbers:true,
                    rownumWidth:30,
                    rowList:[10, 20, 30, 40, 50],
                    prmNames:{
                        page:"page",
                        rows:"size",
                        sort:"sortName",
                        order:"sortOrder"
                    },
                    pager:pager,
                    sortname:'date',
                    viewrecords:true,
                    sortorder:"desc",
                    postData:{
                        "reportFilter.tags":this.getSelectedTags,
                        "reportFilter.message":this.getFilterMessage
                    },
                    jsonReader:{ repeatitems:false, id:"3" },
                    height:'100%',
                    onSelectRow:this.showReportDetails
                }
            );

            return this;
        },

        // Renders table that contains updateable content.
        // This one hasn`t sorting or pagination
        renderRealtimeUpdatesTable:function () {

            var url = '/report/list/' + userId + '/' + this.appId;
            var that = this;

            this.realtimeTable.jqGrid(
                {
                    url:url,
                    datatype:'json',
                    gridview:true,
                    colNames:[
                        'Report message',
                        'Date',
                        'Tags',
                        'id',
                        'appId',
                        'userId'],

                    colModel:[
                        {name:'message', index:'message', width:400, sortable:false},
                        {
                            name:'date',
                            index:'date',
                            width:180,
                            formatter:function (cellValue, options) {
                                if (cellValue) {
                                    return $.fmatter.util.DateFormat(
                                        '',
                                        new Date(+cellValue),
                                        'Y/m/d H:i:s.u',
                                        $.extend({}, $.jgrid.formatter.date, options)
                                    );
                                } else {
                                    return '';
                                }
                            },
                            sortable:false
                        },
                        {name:'tags', width:200, sortable:false},
                        {name:'id', hidden:true},
                        {name:'appId', hidden:true},
                        {name:'userId', hidden:true}
                    ],
                    rowNum:20,
                    loadonce:false,
                    prmNames:{
                        page:"page",
                        rows:"size",
                        sort:"sortName",
                        order:"sortOrder"
                    },
                    rownumbers:true,
                    rownumWidth:30,
                    sortorder:"desc",
                    sortname:"date",
                    postData:{
                        "reportFilter.tags":this.getSelectedTags,
                        "reportFilter.message":""
                    },
                    jsonReader:{ repeatitems:false, id:"3" },
                    height:'100%',
                    onSelectRow:this.showReportDetails
                }
            );

            return this;
        },

        // Brings to view selected reports table (common of with realtime updates)  
        showReportsTable:function (e) {

            // check what table should be shown
            var tableToShow = $(e.target).data("view-mode");

            // if it is already selected then skip the rest
            if (this.currentTable == tableToShow) {
                return;
            }

            this.currentTable = tableToShow;

            // show proper table
            switch (tableToShow) {
                case "normal" :
                {
                    // stop realtime updates
                    clearInterval(this.updatesInterval);

                    this.renderTable();
                    break;
                }

                case "realtime":
                {
                    this.renderRealtimeUpdatesTable();

                    // start realtime updates
                    this.updatesInterval = setInterval(this.checkUpdates, 5000);
                    break;
                }
            }

        },

        // get all tags for this application
        getTags:function () {
            var tags;
            var url = "/report/tags/" + userId + "/" + this.appId;
            $.ajax({
                url:url,
                async:false,
                success:function (result) {
                    tags = result;
                }
            });
            return tags;
        },

        // render tag lists (table view filter and report remove filter)
        renderTagList:function () {

            // get tag list from the server
            this.tagList = this.getTags();

            // clear containers
            this.tagsDropDown.text("");
            this.filterTagsContainer.text("");

            var that = this;

            _.each(this.tagList, function (tag) {

                // if this tag already in table filter then don`t push it into the dropdown
                if (!_.include(that.addedTags, tag)) {
                    // add tags to the table filter dropdown menu
                    that.tagsDropDown.append("<li><a class='tag' id='" + that.getHash(tag) + "' data-tag='" + tag + "'>" + tag + "</a></li>");
                }

                // add tags to the delete filter
                that.filterTagsContainer.append("<option>" + tag + "</option>");
            });

            return this;
        },

        // get md5 hash of the string
        getHash:function (string) {
            var hashedTag = $.md5(string);
            return hashedTag;
        },

        // add tag to the filter
        addTag:function (e) {

            var that = this;
            var tag = $(e.target).data("tag");

            // remove "display all" sign from the tags container
            if (this.addedTags.length == 0) {
                this.tagsContainer.html("");
            }

            // push tag to the added tags array and render it
            this.addedTags.push(tag.toString());
            this.tagsContainer.append("<button type='button' class='btn tag-added'>" + tag + "</button>");

            // remove tag from the dropdown menu
            this.$("#" + that.getHash(tag)).remove();

            this.refreshTable();

        },

        // remove selected tag
        removeTag:function (e) {

            // get tag name
            var tagToRemove = $(e.target).text();
            var that = this;

            // remove from addedTags collection 
            _.each(that.addedTags, function (tag, index) {
                if (tag == tagToRemove) {
                    that.addedTags.splice(index, 1);
                }
            });

            // remove from DOM
            $(e.target).remove();

            // add tag back to the dropdown tag list
            this.tagsDropDown.append("<li><a class='tag' id='" + that.getHash(tagToRemove) + "' data-tag='" + tagToRemove + "'>" + tagToRemove + "</a></li>");

            // if all tags have been detached than display all data
            if (this.addedTags.length == 0) {
                this.tagsContainer.html("<h4> Display all tags.</h4>");
            }

            // refresh view
            this.refreshTable();
        },

        // check if there are some data changes and updates view with fresh data
        refreshView:function () {

            // get tag changes
            this.renderTagList();

            // if refreshing caused by reports deleting , and some tags are
            // not exists anymore then remove them from the view
            var removedTags = _.difference(this.addedTags, this.tagList);
            if (removedTags) {

                // update list of added tags
                this.addedTags = _.intersection(this.addedTags, this.tagList);

                var that = this;

                // remove redundant tags
                _.each(removedTags, function (tag) {
                    $(":contains('" + tag + "')", that.tagsContainer).remove();
                });
            }

            // if all tags have been detached than display all data
            if (this.addedTags.length == 0) {
                this.tagsContainer.html("<h4> Display all tags.</h4>");
            }

            this.refreshTable();
        },

        // init tables reloading
        refreshTable:function () {
            this.reportsTable.setGridParam({page:1});

            // reload table data
            this.reportsTable.trigger("reloadGrid");
            this.realtimeTable.trigger("reloadGrid");

            // clear details view
            this.clearReportDetails();
        },

        // setup delete filter range datepickers
        initializeDatePickers:function () {

            var that = this;
            this.fromDate.datepicker({
                onSelect:function (date) {
                    that.toDate.datepicker("option", {minDate:date});
                },
                onClose:function () {
                    if (!that.fromDate.val()) {
                        that.removeFromClearFilter();
                    }
                }
            });

            this.toDate.datepicker({
                onSelect:function (date) {
                    that.fromDate.datepicker("option", {maxDate:date});
                },
                onClose:function () {
                    if (!that.toDate.val()) {
                        that.removeToClearFilter();
                    }
                }
            });
        },

        deleteReports:function () {
            // get delete mode("all" or "filter")
            var clearMode = this.$("li.reports-clear-mode.active").data("clear");
            var url = "/report/delete/" + userId + "/" + this.appId;
            var allUrl = "/report/deleteAll/" + userId + "/" + this.appId;;
            var filterData;


            // if in "filter" mode then gather filter data
            if (clearMode === "filter") {
                filterData = this.getClearFilterData();

                // when filter mode chosen but nothing have been setted
                if (!filterData) {
                    return;
                }
            }

            // send delete request to the server 
            $.ajax({
                type:'POST',
                url:filterData ? url : allUrl,
                data:filterData ? $.param(filterData) : "",
                dataType:'json',
                async:false
            });

            // if not all reports have been deleted then refresh view
            if (this.reportsExists()) {
                this.refreshView();
            } else {
                this.showNoReportsMessage();
            }
        },

        // gather clear filter data for delete request
        getClearFilterData:function () {


            var result;

            var selectedTags = $("option:selected", this.filterTagsContainer);

            // if date range selected then get filter settings
            if ((this.fromDate.val() || this.toDate.val()) && selectedTags.length > 0) {
                var filterData = {
                    range:{},
                    tags:[]
                };

                filterData.range.from = this.fromDate.val() ?
                    this.fromDate.datepicker("getDate").getTime().toString() : "0";

                filterData.range.to = this.toDate.val() ?
                    this.toDate.datepicker("getDate").getTime().toString() :
                    new Date().getTime().toString();

                // get selected tags
                _.each(selectedTags, function (elem) {
                    filterData.tags.push($(elem).text());
                });

                result = filterData;
            }

            return filterData;
        },

        // show details about selected report
        showReportDetails:function (rowId, status, e) {

            // get report id
            var data = $(e.currentTarget).getRowData(rowId);

            // fetch report details from the server
            var report = new Report({id:data.id});
            var fetchUrl = "/report/get/" + data.id;
            report.fetch({url:fetchUrl, async:false});

            // display details
            var reportView = new ReportView({el:this.$(".details"), model:report});
            reportView.render(reportTemplate);
        },

        // gets currently selected tags for report filtering
        getSelectedTags:function () {
            return this.addedTags.length > 0 ? this.addedTags : this.tagList;
        },

        // get messegae for report filtering
        getFilterMessage:function () {
            return this.filterMessage.val();
        },


        // creates json object that will be sent on real time update request  
        getUpdateCheckData:function () {

            // get date of the last report in the view
            var table = this.realtimeTable;
            var topRowId = table.getDataIDs()[0];
            var lastReportDate = table.getRowData(topRowId).date;

            // get selected tags
            var tagsToSend = this.addedTags.length > 0 ? this.addedTags : this.tagList;

            var data = {
                // add 1 second to the top date cause of Date.parse rounding
                date:(new Date(lastReportDate.replace(/\.\d*$/, ''))).getTime() + 1000,
                tags:tagsToSend
            };

            return $.param(data);
        },

        // check if there are any new reports in the database and if it is then update table
        checkUpdates:function () {

            // gather data for request
            var filterData = this.getUpdateCheckData();
            var url = '/report/list/realtime/' + userId + '/' + this.appId;
            var that = this;

            $.ajax({
                type:'POST',
                url:url,
                data:filterData,
                dataType:'json',
                async:false,
                success:function (response) {
                    if (response) {
                        that.renderRealtimeUpdate(response);
                    }
                }
            });
        },

        // display new reports right after realtime update
        renderRealtimeUpdate:function (newReports) {
            var that = this;

            // hightlight different epochs of report updates
            $(".third-epoch", that.realtimeTable).removeClass("third-epoch");
            $(".second-epoch", that.realtimeTable).addClass("third-epoch").removeClass("second-epoch");
            $(".first-epoch", that.realtimeTable).addClass("second-epoch").removeClass("first-epoch");

            // get array of table ids
            var tableIds = that.realtimeTable.getDataIDs();

            var tableSize = tableIds.length - 1;

            // add new reports and remove redundant
            _.each(newReports, function (report, index) {

                // add report to the top of the table
                that.realtimeTable.addRowData(report.id, report, "first");
                that.realtimeTable.setRowData(report.id, false, "first-epoch");

                // delete last row from the table                     
                that.realtimeTable.delRowData(tableIds[tableSize - index]);
            });
        },

        // add tooltips to the view controls
        renderTooltips:function () {
            var searchBtnMsg = "Search reports by message.";
            var deleteBtnMsg = "Delete reports.";
            var refreshBtnMsg = "Refresh data";

            var delaySettings = {show:500, hide:100};


            // search button
            $(".search").tooltip({
                title:searchBtnMsg,
                placement:"right",
                delay:delaySettings
            });

            // delete button
            $(".delete").tooltip({
                title:deleteBtnMsg,
                placement:"right",
                delay:delaySettings
            });

            // refresh button
            $(".refresh").tooltip({
                title:refreshBtnMsg,
                placement:"left",
                delay:delaySettings
            });

        },

        // if there are no reports for selected app then show notification
        showNoReportsMessage:function () {
            this.reportsView.addClass("hide");
            this.noReportsMessage.removeClass("hide");
        },

        // show report tables and control panel
        showReportsView:function () {
            this.noReportsMessage.addClass("hide");
            this.reportsView.removeClass("hide");
        },

        // clear value of "toDate" datepicker of clear filter 
        removeToClearFilter:function () {
            this.toDate.val("");
            this.fromDate.datepicker("option", {maxDate:null});
        },


        // clear value of "fromDate" datepicker of clear filter 
        removeFromClearFilter:function () {
            this.fromDate.val("");
            this.toDate.datepicker("option", {minDate:null});
        },

        // clear report details view
        clearReportDetails:function () {
            this.detailsContainer.html("");
        }

    });
    return ReportsView;
});

