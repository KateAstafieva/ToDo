define([
    'jquery',
    'underscore',
    'backbone'
], function($, _, Backbone){

    var ReportView = Backbone.View.extend({

        render: function(template){
            var template = _.template($(template).html(), this.model.toJSON());
            this.$el.html(template);
            return this;
        }
    });

    return ReportView;
});
