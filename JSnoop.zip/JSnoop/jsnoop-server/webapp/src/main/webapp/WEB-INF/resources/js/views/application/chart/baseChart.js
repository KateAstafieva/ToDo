define([
    'jquery',
    'underscore',
    'baseview'
], function ($, _, BaseView) {

    var BaseChartView = BaseView.extend({

        initialize : function() {
            //this.g = new Dygraph();
        },

        // if time gap between points greater than predefined then insert 0 values between this points
        initializeTimeGaps:function (data) {

            for (i = 0; i < data.details.length; i++) {
                for (j = 0; j < data.details[i].data.length - 1; j++) {
                    if (data.details[i].data[j + 1].date - data.details[i].data[j].date > this.TIME_GAP*2) {
                        data.details[i].data.splice(j + 1, 0, {date:parseInt(data.details[i].data[j].date) + this.TIME_GAP, reportCounts:"0"});
                        data.details[i].data.splice(j + 2, 0, {date:parseInt(data.details[i].data[j+2].date) - this.TIME_GAP, reportCounts:"0"});
                        j++;
                    } else if (data.details[i].data[j + 1].date - data.details[i].data[j].date > this.TIME_GAP &&
                        data.details[i].data[j + 1].date - data.details[i].data[j].date <= this.TIME_GAP*2)
                    {
                        data.details[i].data.splice(j + 1, 0, {date:parseInt(data.details[i].data[j].date) + this.TIME_GAP, reportCounts:"0"});
                        j++;
                    }
                }
            }
            return data;
        },

        /*

         this.appInfo format:
         [ { appId: "...", appName: "...", details: [ { type:"...", data: [ { date: "...", reportsCount: "..."}, ...]}, ... ]}, ... ]

         ---------------------------------------------------

         Dygraph requires next format:

         "X_label, Y_label1, Y_label2,...\n
         X_value, Y_value1, Y_value2,...\n
         X_value, Y_value1, Y_value2,...\n
         X_value, Y_value1, Y_value2,...\n
         ...
         "

         So here we are creating next structure:

         {
         labels: "<app_name + (report type1), app_name + (report type2), app_name + (report type3), ...>",
         reportData: [ {date: "", reportsCounts: [app_type1_count, app_type2_count, app1_type3_count, ...]}]
         }

         */
        parseData:function (data) {
            var result = {labels:"Date", reportData:{}};

            var currentColumnNumber = 0;

            for (var detailsKey in data.details) {
                result.labels += ", " + data.name + "(" + data.details[detailsKey].type + ")";
                for (var dataKey in data.details[detailsKey].data) {

                    var date = data.details[detailsKey].data[dataKey].date;

                    if (!result.reportData[date]) {
                        result.reportData[date] = {date:date, reportCounts:[]};
                    }

                    // hard to explain...
                    var columnsCount = result.reportData[date].reportCounts.length;
                    if(columnsCount < currentColumnNumber){
                        for(var i = 0; i<currentColumnNumber-columnsCount; i++){
                            result.reportData[date].reportCounts.push(0);
                        }
                    }

                    result.reportData[date].reportCounts.push(data.details[detailsKey].data[dataKey].reportCounts);
                }
                currentColumnNumber++;
            }


            //  in the end we should fill reportData.reportCounts to the end
            // with blank values for proper Dygraph render

            var columnsCount = this.appInfo.details.length;

            for (var dataKey in result.reportData) {
                var reportsLength = result.reportData[dataKey].reportCounts.length;
                for (var i = 0; i < columnsCount - reportsLength; i++) {
                    result.reportData[dataKey].reportCounts.push(0);
                }
            }

            return result;
        },

        // stringify parsed collection
        createChartModel:function (data) {

            var model = "" + data.labels + "\n";
            var reportData = this.sortObj(data.reportData);

            $.each(reportData, function (index, value) {
                var date = new Date(parseInt(value.date)).strftime('%Y-%m-%d %H:%M:%S');

                model += date + ", " + value.reportCounts.toString() + "\n";
            });
            return model;
        },

        // sort object by keys
        sortObj:function (arr) {
            // Setup Arrays
            var sortedKeys = new Array();
            var sortedObj = {};

            // Separate keys and sort them
            for (var i in arr) {
                sortedKeys.push(i);
            }
            sortedKeys.sort();

            // Reconstruct sorted obj based on keys
            for (var i in sortedKeys) {
                sortedObj[sortedKeys[i]] = arr[sortedKeys[i]];
            }
            return sortedObj;
        },

        // calculates zoom modifiers, considering current cursor position
        calculateZoomModifiers: function(mouseEvent) {

            // actual plot area of the chart is a little bit shifted from the left 
            // edge of chart, so we should take it into account when calculating zoom modifiers
            var cursorError = 55;

            var chartWidth = this.g.getArea().w;    // chart component width
            var cursorX = this.g.eventToDomCoords(mouseEvent)[0] - cursorError;     // cursor position

            var minModifier = cursorX / (chartWidth / 2);
            var maxModifier = (chartWidth - cursorX) / (chartWidth/2);

            return {min: minModifier, max: maxModifier};
        },

        zoomIn: function(scale, minModifier, maxModifier) {

            var range = this.getCurrentMaxDate() - this.getCurrentMinDate();

            // apply zoom modifiers if they are specified, else - make a simple zoom
            var maxShift = maxModifier ? range*scale*maxModifier : range*scale;
            var minShift = minModifier ? range*scale*minModifier : range*scale;

            var newMaxDate = this.getCurrentMaxDate() - maxShift;
            var newMinDate = this.getCurrentMinDate() + minShift;

            this.setDateRange(newMinDate, newMaxDate);
        },

        zoomOut: function(scale, minModifier,maxModifier){
            var range = this.getCurrentMaxDate() - this.getCurrentMinDate();

            // apply zoom modifiers if they are specified, else - make a simple zoom
            var maxShift = maxModifier ? range*scale*maxModifier : range*scale;
            var minShift = minModifier ? range*scale*minModifier : range*scale;

            var newMaxDate = this.getCurrentMaxDate() + maxShift;
            var newMinDate = this.getCurrentMinDate() - minShift;

            this.setDateRange(newMinDate, newMaxDate);
        },


        setDateRange: function(from, to){
            this.g.updateOptions({dateWindow:[from, to]});
        },

        setCurrentMinDate:function (date) {
            this.g.updateOptions({dateWindow:[date, this.getCurrentMaxDate()]});
        },

        setCurrentMaxDate:function (date) {
            this.g.updateOptions({dateWindow:[this.getCurrentMinDate(), date ]});
        },

        resetCurrentMaxDate:function () {
            this.g.updateOptions({dateWindow:[this.getCurrentMinDate(), this.getMaxDate()]});
        },

        resetCurrentMinDate:function () {
            this.g.updateOptions({dateWindow:[this.getMinDate(), this.getCurrentMaxDate()]});
        },

        getMinDate:function () {
            return this.g.xAxisExtremes()[0];
        },

        getMaxDate:function () {
            return this.g.xAxisExtremes()[1];
        },

        getCurrentMinDate:function () {
            return this.g.xAxisRange()[0];
        },

        getCurrentMaxDate:function () {
            return this.g.xAxisRange()[1];
        }

    });

    return BaseChartView;
});

