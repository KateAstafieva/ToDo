define([
    'jquery',
    'underscore',
    'backbone'
], function($, _, Backbone){
    var Application = Backbone.Model.extend({
        idAttribute: "appId",
        defaults: {
            name: "",
            appId: ""
        },

        // initialize access type property for this application
        initializeAccess: function(userEmail){
            var fullAccess = this.canBeChangedBy(userEmail);
            this.set("fullAccess", fullAccess);
        },

        // check if user with specified email has full access to this application 
        canBeChangedBy : function(userEmail){
            var shareInfo = this.get("shareInfo");

            // check if user is owner or have full access to this application
            return shareInfo.owner == userEmail ||
                _.any(shareInfo.users, function(user){
                    return user.email == userEmail && user.access == "FULL";
                });
        }
    });
    return Application;
});
