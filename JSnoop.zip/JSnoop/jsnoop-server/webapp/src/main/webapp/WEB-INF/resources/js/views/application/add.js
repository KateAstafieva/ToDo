define([
    'jquery',
    'underscore',
    'backbone',
    'models/application',
    'text!templates/application/edit.html',
    'text!templates/application/addOption.html'

], function ($, _, Backbone, Application, editTemplate, addOptionTemplate) {
    var AddView = Backbone.View.extend({

        initialize:function () {
            _.bindAll(this, 'addSuccess');
            this.NAME_RULE = /^[A-Za-z0-9\-\ \_]{0,}$/;

        },

        render:function (template) {
            var template = _.template($(template).html());
            this.$el.html(template);
            this.input = $("#edit");
            return this;
        },

        events:{
            "click #addAppOption":"showAddForm",
            "click #save":"addApp",
            "click #cancel":"cancelAdd"
        },

        showAddForm:function () {
            this.render(editTemplate);
            this.input.focus();
        },

        //add created application into the collection
        addApp:function () {
            var appName = this.input.val();
            if (!appName.match(this.NAME_RULE)) {
                this.input.focus();
                return;
            } else {
                var newApp = new Application({name:appName });
                var saveUrl = "/apps/add/" + userId;
                newApp.save({},{url: saveUrl, success: this.addSuccess});
            }
        },

        cancelAdd:function () {
            this.render(addOptionTemplate);
        },

        // handle response after add operation
        addSuccess:function (collection, response) {
            if (!response) {
                // if it is none, then an error ocured 
                this.showAppExistsPopup();
            } else {

                // if success then add new aplication view to the applications list                
                var appToAdd = new Application(response);
                this.$el.trigger("appAdd", appToAdd);
                this.cancelAdd();
            }
        },

        showAppExistsPopup: function(){
            alert("App with such name already exists!");
        }
    });

    return AddView;
});

