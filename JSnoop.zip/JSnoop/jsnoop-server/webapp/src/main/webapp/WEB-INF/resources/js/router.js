// Filename: router.js
define([
    'jquery',
    'underscore',
    'backbone',
    'views/application/list',
    'views/report/list',
    'views/application/chart/simpleChart',
    'views/application/chart/realtimeChart'

], function ($, _, Backbone, ApplicationsView, ReportsView, SimpleChartView, RealtimeChartView) {
    var AppRouter = Backbone.Router.extend({
        routes:{
            "":"defaultRoute",
            "reports/list/:appId":"showReports",
            "reports/chart/:appId": "showReportChart",
            "reports/chart/realtime/:appId": "showRealtimeChart"
        },

        showReports:function (appId) {
            this.showView(new ReportsView({appId:appId}));
        },

        showReportChart: function(appId){
            this.showView(new SimpleChartView({appId: appId}));
        },

        showRealtimeChart: function(appId){
            this.showView(new RealtimeChartView({appId: appId}));
        },

        defaultRoute:function () {
            this.showView(new ApplicationsView());
        },

        disposePreviousView: function(){
            if(this.currentView) {
                this.currentView.dispose();
            }
        },

        showView: function(view){
            this.disposePreviousView();
            view.render();
            this.currentView = view;
        }
    });

    var initialize = function () {
        var app_router = new AppRouter();
        Backbone.history.start();
    };
    return {
        initialize:initialize
    };
});
 