define([
    'jquery',
    'underscore',
    'views/application/chart/baseChart',
    'text!templates/application/realtimeGraph.html'
], function ($, _, BaseChart, graphViewTemplate) {

    var RealtimeChartView = BaseChart.extend({

        el:$("#mainView"),

        initialize:function (options) {
            _.bindAll(this,
                "createChartModel",
                "fetchNewData",
                "updateGraph"
            );
            this.TIME_GAP = 1000;    // one second between timestamps on graph
            this.UPDATES_INTERVAL = 5000;
            this.START_TIME = new Date().getTime() - (30 * 60 * 1000);   // fetch info about reports for last 30 minutes

            this.appInfo = this.getAppInfo(options.appId);
            this.saveLastUpdateTime();
        },


        // fetch data about reports activity for this application
        getAppInfo:function (appId) {
            var appInfo = {};
            var fetchUrl = "/report/chart/realtime/" + userId + "/" + appId;

            $.ajax({
                url:fetchUrl,
                data: {fromDate: this.START_TIME},
                async:false,
                success:function (response) {
                    appInfo = JSON.parse(response);
                }
            });

            return appInfo;
        },

        // this methow will be invoked by the router on the view unloading         
        dispose:function () {

            // stop realtime updating if it is hadn`t stoped
            clearInterval(this.updatesInterval);

            // call baseview dispose method
            BaseChart.prototype.dispose.call(this);
        },

        render:function () {
            var template = _.template($(graphViewTemplate).html(), this.appInfo);
            this.$el.html(template);

            this.graph = this.$(".realtime-graph");
            this.noReports= this.$(".no-reports-message");

            if(this.reportsExists()) {
                this.hideNoReportsMessage();
            }

            this.renderGraph();
            this.fetchNewData();
            this.startUpdates();
            return this;
        },

        reportsExists:function () {
            return this.appInfo.details.length > 0;
        },

        saveLastUpdateTime: function(){
            this.lastUpdateTime = new Date().getTime();
        },

        renderGraph:function () {
            // parse collection and create model for Dygraph lib
            var data = BaseChart.prototype.initializeTimeGaps.call(this, this.appInfo);
            var parsedData = BaseChart.prototype.parseData.call(this, data);
            var model = BaseChart.prototype.createChartModel.call(this, parsedData);
            this.g = new Dygraph(
                this.graph.get(0),
                model,
                {
                    height:350,
                    animatedZooms:false,
                    xAxisLabelWidth:60,
                    axes:{
                        x:{
                            pixelsPerLabel:100
                        }
                    }
                }
            );
        },

        startUpdates: function() {
            this.updatesInterval = setInterval(this.fetchNewData, this.UPDATES_INTERVAL);
        },

        getLastTimestamp: function(){
            if(this.reportsExists()){
                return this.g.xAxisExtremes()[1];
            } else {
                return this.lastUpdateTime;
            }
        },

        // fetch info about recent report activity
        fetchNewData: function(){
            var that = this;
            var oneSecond = 1000;
            var sendData = {fromDate: this.getLastTimestamp()+1000};
            this.saveLastUpdateTime();
            $.ajax({
                url: "/report/chart/realtime/" + userId + "/" + this.options.appId,
                data: sendData,
                type: "GET",
                success: that.updateGraph
            });
        },

        // parse server response and add it to current chart model
        updateGraph: function(newData){
            var that = this;
            var newDataAsJson = JSON.parse(newData);
            var zeroReportStamp = {date: new Date().getTime(), reportCounts: 0};

            // if there are new reports data then append it to the old one and update chart
            if(newDataAsJson.details.length>0) {
                this.hideNoReportsMessage();
                _.each(newDataAsJson.details, function(reportDetails){

                    var detailsIndex;

                    // find reports of this type
                    _.each(that.appInfo.details, function(details, index){
                        if (details.type == reportDetails.type) {
                            detailsIndex = index;
                        }
                    });

                    // if reports of this type are already on the chart then append new data
                    if(detailsIndex != undefined) {
                        that.appInfo.details[detailsIndex].data = that.appInfo.details[detailsIndex].data.concat(reportDetails.data);
                    } else {
                        // if there are no reports of this type on the chart then add new chart series
                        that.appInfo.details.push(reportDetails);
                    }
                });

                // if there are no new reports then just insert 0 values to the chart model
            } else {
                _.each(this.appInfo.details, function(reportDetails){
                    reportDetails.data.push(zeroReportStamp);
                });
            }

            // parse model and update chart
            // parse collection and create model for Dygraph lib
            var data = BaseChart.prototype.initializeTimeGaps.call(this, this.appInfo);
            var parsedData = BaseChart.prototype.parseData.call(this, data);
            var model = BaseChart.prototype.createChartModel.call(this, parsedData);
            this.g.updateOptions( { 'file': model } );
        },

        showNoReportsMessage:function () {
            this.noReports.show();
        },

        hideNoReportsMessage: function(){
            this.noReports.hide();
        }

    });

    return RealtimeChartView;
});

