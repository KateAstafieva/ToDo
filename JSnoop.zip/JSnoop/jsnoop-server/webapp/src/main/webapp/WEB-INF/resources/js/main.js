require.config({
    paths:{
        jquery:'lib/jquery-1.7.1.min',
        underscore:'lib/underscore-min',
        backbone:'lib/backbone-min',
        bootstrap: 'lib/bootstrap',
        baseview:'views/baseview',
        text:'lib/text',
        templates:'../templates',
        jqGridLocale:'lib/grid.locale-en',
        jqGrid:'lib/jquery.jqGrid.min',
        md5:'lib/md5',
        json2: 'lib/json2',
        jqueryUI:'lib/jquery-ui-1.8.23.custom.min',
        dygraph:'lib/dygraph',
        timepicker: 'lib/timepicker',
        mousewheel: 'lib/jquery.mousewheel'
    },
    shim:{
        backbone: {
            deps:['underscore']
        },


        md5:{
            deps:[
                'jquery'
            ]
        },

        jqueryUI:{
            deps:[
                'jquery'
            ]
        },

        jqGridLocale:{
            deps:[
                'jquery',
                'md5'
            ]
        },

        jqGrid:{
            deps:[
                'jquery',
                'lib/jquery.transition.min',
                'jqGridLocale',
                'jqueryUI'
            ]
        },

        timepicker: {
            deps: [
                'jqueryUI'
            ]
        },

        dygraph:{
            deps:[
                'jqueryUI'
            ]
        },

        'views/application/chart/baseChart': {
            deps:[
                'dygraph',
                'timepicker',
                'mousewheel'
            ]
        },

        'views/report/list':{
            deps:[
                'bootstrap',
                'json2'
            ]
        }
    }
});

require([

    // Load our app module and pass it to our definition function
    'app'

    // Some plugins have to be loaded in order due to their non AMD compliance
    // Because these scripts are not "modules" they do not pass any values to the definition function below
], function (App) {


    //start application
    App.initialize();
});

