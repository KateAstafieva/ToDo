define([
    'jquery',
    'underscore',
    'backbone',
    'models/application'
], function($, _, Backbone, applicationModel){

    var Applications = Backbone.Collection.extend({
        model: applicationModel,
        url: "/apps/add/" + userId
    });

    return Applications;
});
