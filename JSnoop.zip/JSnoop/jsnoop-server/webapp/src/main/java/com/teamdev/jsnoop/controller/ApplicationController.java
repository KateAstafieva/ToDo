package com.teamdev.jsnoop.controller;

import com.teamdev.jsnoop.model.user.application.Application;
import com.teamdev.jsnoop.service.application.ApplicationService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.validation.Valid;
import java.io.UnsupportedEncodingException;
import java.util.List;

/**
 * Author: Alexander Serebriyan
 * Date: 18.05.12
 */
@Controller
@RequestMapping("/apps")
public class ApplicationController {
    private final static Logger LOG = Logger.getLogger(ApplicationController.class);

    private final ApplicationService applicationService;

    @Autowired
    public ApplicationController(ApplicationService applicationService) {
        this.applicationService = applicationService;
    }

    @RequestMapping(value = "/get/{userId}/{appId}", method = RequestMethod.GET)
    @ResponseBody
    public Application getApp(@PathVariable("userId") String userId,
                              @PathVariable("appId") String appId) {
        LOG.info("Getting application for User ID: " + userId + ". Application ID: " + appId);

        return applicationService.findApp(appId);
    }

    @RequestMapping("/list/{userId}")
    @ResponseBody
    public List<Application> listApps(@PathVariable("userId") String userId) {
        LOG.info("Listing apps for User ID: " + userId);
        List<Application> apps = applicationService.listApplications(userId);
        return apps;
    }

    @RequestMapping(value = "/add/{userId}", method = RequestMethod.PUT)
    @ResponseBody
    public Application addApp(@PathVariable("userId") String userId,
                              @Valid @RequestBody Application app) {
        LOG.info("Adding application for User ID: " + userId + ". Application: " + app);
        return applicationService.saveApp(userId, app);
    }

    @RequestMapping(value = "/delete/{userId}/{appId}", method = RequestMethod.DELETE)
    @ResponseBody
    public String deleteApp(@PathVariable("userId") String userId,
                            @PathVariable("appId") String appId) {
        LOG.info("Deleting application for User ID: " + userId + ". Application ID: " + appId);

        if (applicationService.userHaveFullAccess(userId, appId)) {
            applicationService.removeApp(appId);
        }

        return appId;
    }

    @RequestMapping(value = "/edit/{userId}", method = RequestMethod.POST)
    @ResponseBody
    public Application renameApp(@PathVariable("userId") String userId,
                                 @Valid Application app) {
        LOG.info("Editing application with id: " + app.getAppId() + " for User ID: " + userId + ". New name: " + app.getName());

        if (applicationService.userHaveFullAccess(userId, app.getAppId())) {
            return applicationService.updateApp(userId, app.getAppId(), app.getName());
        }

        return app;
    }


    @RequestMapping(value = "/share/{userId}", method = RequestMethod.POST)
    @ResponseBody
    public void shareApp(@PathVariable("userId") String userId,
                         @RequestParam("email") String email,
                         @RequestParam("access") String access,
                         @RequestParam("appId") String appId) throws MessagingException, UnsupportedEncodingException {

        LOG.info("Sharing application " + appId + " by user " + userId + " with " + email + " and access type " + access);
        applicationService.shareApp(appId, email, access, userId);
    }

}
