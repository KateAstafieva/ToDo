package com.teamdev.jsnoop.controller;

import com.teamdev.jsnoop.dao.UserRepository;
import com.teamdev.jsnoop.model.user.User;
import com.teamdev.jsnoop.service.application.ApplicationService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * Author: Alexander Serebriyan
 * Date: 17.05.12
 */

@Controller
public class HomeController {

    private final static Logger LOG = Logger.getLogger(HomeController.class);

    private final UserRepository userRepository;
    private final ApplicationService applicationService;


    @Autowired
    public HomeController(UserRepository userRepository,
                          ApplicationService applicationService) {
        this.userRepository = userRepository;
        this.applicationService = applicationService;
    }

    @RequestMapping({"/index", "/", "/login", "/loginfailed"})
    public String indexRequest() {
        return "login";
    }

    @RequestMapping("/welcome")
    public String welcomeRequest(Map<String, Object> model, HttpServletRequest request) {

        if (request.getUserPrincipal() == null) {
            return "redirect:/login";
        }


        User user = userRepository.findByUserId(request.getUserPrincipal().getName());
        model.put("user", user);
        return "welcome";
    }

    @RequestMapping("/welcome/{key}")

    public String welcomeShare(@PathVariable("key") String key, Map<String, Object> model,
                               HttpServletRequest request, HttpServletResponse resp) throws IOException, ServletException {
        User user = userRepository.findByUserId(request.getUserPrincipal().getName());
        if (applicationService.sharedWithNewUser(key, user.getEmail())) {
            resp.sendRedirect(request.getContextPath() + "/welcome");
            model.put("user", user);
            return "welcome";
        } else {
            return "bugkey";
        }


    }
}
