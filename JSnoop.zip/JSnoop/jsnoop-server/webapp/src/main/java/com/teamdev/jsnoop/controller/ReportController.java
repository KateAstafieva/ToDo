package com.teamdev.jsnoop.controller;

import com.teamdev.jsnoop.model.report.Report;
import com.teamdev.jsnoop.model.report.ReportsTableRequest;
import com.teamdev.jsnoop.service.Utils;
import com.teamdev.jsnoop.service.application.ApplicationService;
import com.teamdev.jsnoop.service.report.ReportService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Order;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

/**
 * Author: Alexander Serebriyan
 * Date: 29.05.12
 */
@Controller
@RequestMapping("/report")
public class ReportController {

    private static final int UPDATEABLE_TABLE_ROWCOUNT = 20;
    private final static Logger LOG = Logger.getLogger(ReportController.class);

    private final MongoTemplate mongoTemplate;
    private final ReportService reportService;
    private final ApplicationService applicationService;


    @Autowired
    public ReportController(MongoTemplate mongoTemplate,
                            ReportService reportService,
                            ApplicationService applicationService) {
        this.mongoTemplate = mongoTemplate;
        this.reportService = reportService;
        this.applicationService = applicationService;
    }

    @RequestMapping("/get/{id}")
    @ResponseBody
    public Report getReport(@PathVariable("id") String id) {
        LOG.info("Getting report with id: " + id);

        return reportService.getReport(id);
    }

    @RequestMapping("/list/{userId}/{appId}")
    @ResponseBody
    public String listReports(@PathVariable("userId") String userId,
                              @PathVariable("appId") String appId,
                              ReportsTableRequest request) throws IOException {

        LOG.info("Listing reports for user " + userId + " and application " + appId + "" +
                " with next parameters:" + request.toString());

        if (!applicationService.userHaveReadAccess(userId, appId)) {
            return null;
        }

        final Sort.Order order = new Sort.Order(Sort.Direction.fromString(request.getSortOrder().toUpperCase()), request.getSortName());
        final PageRequest pageRequest = new PageRequest(request.getPage() - 1, request.getSize(), new Sort(order));
        final Page<Report> reports;

        List<String> tags = request.getReportFilter().getTags();
        String message = request.getReportFilter().getMessage();

        reports = reportService.listReports(appId, message, tags, pageRequest);
        return Utils.pageToJson(reports);
    }


    @RequestMapping(value = "/list/realtime/{userId}/{appId}", method = RequestMethod.POST)
    @ResponseBody
    public List<Report> realTimeReportsList(@PathVariable("userId") String userId,
                                            @PathVariable("appId") String appId,
                                            @RequestParam("date") Long date,
                                            @RequestParam("tags[]") List<String> tags) throws IOException {


        LOG.info("Realtime update request from user " + userId + " for application " + appId + " with next params: \nDate: " + date + "\nTags: " + tags);

        if (!applicationService.userHaveReadAccess(userId, appId)) {
            return null;
        }

        Query query = new Query(Criteria.where("appId").is(appId).and("date").gt(date).and("tags").in(tags)).limit(UPDATEABLE_TABLE_ROWCOUNT);
        query.sort().on("date", Order.ASCENDING);

        List<Report> reports = mongoTemplate.find(query, Report.class);
        return reports;
    }


    @RequestMapping("/hasReports/{userId}/{appId}")
    @ResponseBody
    public Boolean reportsExists(@PathVariable("userId") String userId,
                                 @PathVariable("appId") String appId) {

        LOG.info("Check for reports existence from user " + userId + " for application " + appId);
        return applicationService.userHaveReadAccess(userId, appId) && reportService.reportsExists(appId);
    }

    @RequestMapping("/tags/{userId}/{appId}")
    @ResponseBody
    public List listTags(@PathVariable("userId") String userId,
                         @PathVariable("appId") String appId) {

        LOG.info("Listing tags for user " + userId + " and application " + appId);

        List tags = reportService.listTags(appId);
        return tags;
    }


    @RequestMapping("/chart/{userId}/{appId}")
    @ResponseBody
    public String getChartModel(@PathVariable("userId") String userId,
                                @PathVariable("appId") String appId) {

        LOG.info("Getting chart model by user " + userId + " for application: " + appId);

        String chartModel = "";
        if (applicationService.userHaveReadAccess(userId, appId)) {
            chartModel = reportService.getChartModel(appId);
        } else {
            chartModel = reportService.getEmptyChartModel();
        }

        return chartModel;
    }

    @RequestMapping("/chart/realtime/{userId}/{appId}")
    @ResponseBody
    public String getRealtimeChartModel(@PathVariable("userId") String userId,
                                        @PathVariable("appId") String appId,
                                        @RequestParam("fromDate") long date) {

        LOG.info("Getting chart model by user " + userId + " for application: " + appId);

        String chartModel = "";
        if (applicationService.userHaveReadAccess(userId, appId)) {
            chartModel = reportService.getChartModel(appId, date);
        } else {
            chartModel = reportService.getEmptyChartModel();
        }

        return chartModel;
    }

    @RequestMapping("/delete/{userId}/{appId}")
    @ResponseBody
    public void deleteReports(@PathVariable("userId") String userId,
                              @PathVariable("appId") String appId,
                              @RequestParam("range[from]") Long from,
                              @RequestParam("range[to]") Long to,
                              @RequestParam("tags[]") List<String> tags) {
        LOG.info("Deleting reports by user " + userId + " for application " + appId + " with date lies between " + from + " and " + to + " and next tags: " + tags);

        if (applicationService.userHaveFullAccess(userId, appId)) {
            reportService.deleteReports(appId, from, to, tags);
        }
    }


    @RequestMapping("/deleteAll/{userId}/{appId}")
    @ResponseBody
    public void deleteAllReports(@PathVariable("userId") String userId,
                                 @PathVariable("appId") String appId) {
        LOG.info("Deleting all reports by user " + userId + " for application " + appId);

        if (applicationService.userHaveFullAccess(userId, appId)) {
            reportService.deleteAllReports(appId);
        }
    }


}
