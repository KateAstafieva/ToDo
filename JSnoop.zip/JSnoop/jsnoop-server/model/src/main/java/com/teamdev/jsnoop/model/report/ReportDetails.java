package com.teamdev.jsnoop.model.report;

import java.util.List;

/**
 * Author: Alexander Serebriyan
 * Date: 28.05.12
 */
public class ReportDetails {
    private String mode;
    private String message;
    private List<StackItem> stack;

    public ReportDetails() {
    }

    public ReportDetails(String mode, String message, List<StackItem> stack) {
        this.mode = mode;
        this.message = message;

        this.stack = stack;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<StackItem> getStack() {
        return stack;
    }

    public void setStack(List<StackItem> stack) {
        this.stack = stack;
    }
}

