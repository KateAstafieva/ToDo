package com.teamdev.jsnoop.model.user.application;

import java.util.LinkedList;
import java.util.List;

/**
 * @author sergey.pensov
 */
public class ShareInfo {

    private List<UserShareInfo> users = new LinkedList<UserShareInfo>();
    private String owner = "";

    public void setUsers(UserShareInfo user) {
        users.add(user);
    }

    public void setOwner(String user) {
        owner = user;
    }

    public String getOwner() {
        return owner;
    }

    public List<UserShareInfo> getUsers() {
        return users;
    }

    public String toString() {
        String result = "ShareInfo{owner=" + owner;
        if (users.size() > 0) {
            result = result + "users=" + users.toString();
        }
        result = result + "}";

        return result;
    }
}
