package com.teamdev.jsnoop.model.report;

/**
 * Author: Alexander Serebriyan
 * Date: 19.09.12
 */
public enum ReportType {
    JS, JAVA
}
