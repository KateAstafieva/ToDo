package com.teamdev.jsnoop.model.report;

import java.util.List;

/**
 * Author: Alexander Serebriyan
 * Date: 10.09.12
 */
public class ReportFilter {
    private List<String> tags;
    private String message;

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString(){
        return "Tags: " + tags.toString() + "\nMessage: " + message;
    }
}
