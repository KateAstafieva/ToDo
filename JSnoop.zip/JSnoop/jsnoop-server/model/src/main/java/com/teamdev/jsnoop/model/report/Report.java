package com.teamdev.jsnoop.model.report;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Set;

/**
 * Author: Alexander Serebriyan
 * Date: 28.05.12
 */
@Document(collection = "reports")
public class Report {

    @Id
    private String id;
    private String userId;
    private String appId;
    private String message;
    private ReportType type;
    private Set<String> tags;
    private ReportDetails details;
    private long date;
    private Object extras;


    public Report() {
    }

    public Report(String userId, String appId, String message, Set<String> tags, ReportDetails details, long date) {
        this.userId = userId;
        this.appId = appId;
        this.message = message;
        this.tags = tags;
        this.details = details;
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Set<String> getTags() {
        return tags;
    }

    public void setTags(Set<String> tags) {
        this.tags = tags;
    }

    public ReportDetails getDetails() {
        return details;
    }

    public void setDetails(ReportDetails details) {
        this.details = details;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public Object getExtras() {
        return extras;
    }

    public void setExtras(Object extras) {
        this.extras = extras;
    }

    public ReportType getType() {
        return type;
    }

    public void setType(ReportType type) {
        this.type = type;
    }
}
