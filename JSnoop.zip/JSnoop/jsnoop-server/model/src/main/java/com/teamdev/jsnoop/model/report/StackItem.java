package com.teamdev.jsnoop.model.report;

import java.util.List;

/**
 * Author: Alexander Serebriyan
 * Date: 29.05.12
 */
public class StackItem {
    private int line;
    private String url;
    private String func;
    private List<String> context;

    public StackItem() {
    }

    public StackItem(int line, String url, String function, List<String> context) {
        this.line = line;
        this.url = url;
        this.func = function;
        this.context = context;
    }

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line = line;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getFunc() {
        return func;
    }

    public void setFunc(String function) {
        this.func = function;
    }

    public List<String> getContext() {
        return context;
    }

    public void setContext(List<String> context) {
        this.context = context;
    }
}
