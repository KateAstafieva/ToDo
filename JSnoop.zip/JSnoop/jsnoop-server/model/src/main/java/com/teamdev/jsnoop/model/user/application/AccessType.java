package com.teamdev.jsnoop.model.user.application;

/**
 * Author: Andrew.Palval@teamdev.com
 *
 * Defines access type to shared application.
 */
public enum AccessType {
    FULL, READ, DENIED
}
