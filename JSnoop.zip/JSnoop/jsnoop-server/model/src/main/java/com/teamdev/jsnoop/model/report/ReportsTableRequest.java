package com.teamdev.jsnoop.model.report;


/**
 * Author: Alexander Serebriyan
 * Date: 06.09.12
 */

/**
 * Encapsulates info with reports table request data, such as pagination parameters, filter data etc.
 */


public class ReportsTableRequest {

    private String sortOrder;
    private String sortName;
    private int page;
    private int size;

    ReportFilter reportFilter;

    public String getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    public String getSortName() {
        return sortName;
    }

    public void setSortName(String sortName) {
        this.sortName = sortName;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public ReportFilter getReportFilter() {
        return reportFilter;
    }

    public void setReportFilter(ReportFilter reportFilter) {
        this.reportFilter = reportFilter;
    }

    @Override
    public String toString(){
        return "Page: " + page + "\nPage size: " + size + "\nOrder: " + sortOrder + "\nOrder by: " + sortName + "\nFilter data: " + reportFilter.toString();
    }
}
