package com.teamdev.jsnoop.model.user.application;

import org.springframework.data.mongodb.core.index.Indexed;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * Author: Alexander Serebriyan
 * Date: 18.05.12
 */

public class Application {

    private String appId;

    @NotNull
    @Size(min = 1)
    @Indexed(unique = true)
    private String name;

    private String settings;
    private ShareInfo shareInfo = new ShareInfo();

    public Application() {
    }

    public Application(String name, String appId) {
        this.name = name;
        this.appId = appId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getSettings() {
        return settings;
    }

    public void setSettings(String settings) {
        this.settings = settings;
    }

    public void setOwnerUser(String user) {
        shareInfo.setOwner(user);
    }

    public void setShareUser(UserShareInfo user) {
        shareInfo.setUsers(user);
    }

    public ShareInfo getShareInfo() {
        return shareInfo;
    }


    @Override
    public String toString() {
        return "Application{" +
                "appId='" + appId + '\'' +
                ", name='" + name + '\'' +
                ", settings='" + "" + '\'' +
                '}';
    }
}
