package com.teamdev.jsnoop.model.user;

import com.teamdev.jsnoop.model.user.application.AccessType;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * @author Sergey Pensov
 */
@Document(collection = "keys")
public class Key {
    @Id
    private String key;

    private String adminMail;

    private String appId;
    private AccessType access = AccessType.FULL;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getAdminMail() {
        return adminMail;
    }

    public void setAdminMail(String adminMail) {
        this.adminMail = adminMail;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public AccessType getAccess() {
        return access;
    }

    public void setAccess(AccessType access) {
        this.access = access;
    }


}
