package com.teamdev.jsnoop.model.user;

import com.teamdev.jsnoop.model.user.application.Application;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

/**
 * Author: Alexander Serebriyan
 * Date: 18.05.12
 */

@Document(collection = "users")
public class User {

    @Id
    private String userId;

    @NotNull
    private String email;

    private List<Application> applications = new ArrayList<Application>();

    public User() {
    }

    public User(String email) {
        this.email = email;
    }

    public User(String userId, String email) {
        this.email = email;
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<Application> getApps() {
        return applications;
    }

    public void setApps(List<Application> apps) {
        this.applications = apps;
    }

    public void addApp(Application app) {
        this.applications.add(app);
    }


}
