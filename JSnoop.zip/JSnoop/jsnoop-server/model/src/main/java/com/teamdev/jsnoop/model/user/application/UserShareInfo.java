package com.teamdev.jsnoop.model.user.application;

/**
 * Author: Andrew.Palval@teamdev.com
 *
 * Bean contains share info for user. Used in list of users in <code>ShareInfo</code> for the application
 */
public class UserShareInfo {
    private String email;
    private AccessType access = AccessType.FULL;

    public UserShareInfo() {
    }

    public UserShareInfo(String email) {
        this.email = email;
    }

    public UserShareInfo(String email, AccessType access) {
        this.email = email;
        this.access = access;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public AccessType getAccess() {
        return this.access;
    }

    public void setAccess(AccessType access) {
        this.access = access;
    }
}
