package com.teamdev.jsnoop.dao;

import com.teamdev.jsnoop.model.report.Report;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Author: Alexander Serebriyan
 * Date: 20.08.12
 */
@Repository
public interface ReportRepository extends CrudRepository<Report, String>, PagingAndSortingRepository<Report, String> {

    @Query("{'appId':?0}")
    Page<Report> list(String appId, Pageable pageable);

    @Query("{'appId':?0, 'tags' : {$in:?1}}")
    Page<Report> listByTags(String appId, List<String> tags, Pageable pageable);

    @Query("{'appId':?0, 'message': {$regex:?1, $options: 'm'}, 'tags' : {$in:?2}}")
    Page<Report> listByTagsAndMessage(String appId,String message, List<String> tags, Pageable pageable);
}
