package com.teamdev.jsnoop.dao;

import com.teamdev.jsnoop.model.report.Report;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

/**
 * @author Sergey Pensov
 */
@Repository
public interface KeyRepository extends CrudRepository<Report, String>, PagingAndSortingRepository<Report, String> {

}
