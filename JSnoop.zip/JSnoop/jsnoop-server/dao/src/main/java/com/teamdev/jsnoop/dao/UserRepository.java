package com.teamdev.jsnoop.dao;


import com.teamdev.jsnoop.model.user.User;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

/**
 * Author: Alexander Serebriyan
 * Date: 18.05.12
 */

@Repository
public interface UserRepository extends PagingAndSortingRepository<User, String> {

    User findByEmail(String email);

    User findByUserId(String userId);

    @Query("{_id:?0},{$pull:{applications.appId:?1}}")
    void removeApplication(String userId, String appId);
}

