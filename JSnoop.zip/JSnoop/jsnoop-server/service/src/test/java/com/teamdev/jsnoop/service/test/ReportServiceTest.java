package com.teamdev.jsnoop.service.test;

import com.teamdev.jsnoop.service.report.ReportService;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;

import static junit.framework.Assert.assertTrue;

/**
 * Author: Alexander Serebriyan
 * Date: 29.05.12
 */

public class ReportServiceTest {

    @Test
    public void testSomething() {

        assertTrue(true);

    }

}
