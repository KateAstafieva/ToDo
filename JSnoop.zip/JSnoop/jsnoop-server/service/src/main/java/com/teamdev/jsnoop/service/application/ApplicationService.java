package com.teamdev.jsnoop.service.application;

import com.mongodb.BasicDBObject;
import com.teamdev.jsnoop.dao.KeyRepository;
import com.teamdev.jsnoop.dao.UserRepository;
import com.teamdev.jsnoop.model.user.Key;
import com.teamdev.jsnoop.model.user.User;
import com.teamdev.jsnoop.model.user.application.AccessType;
import com.teamdev.jsnoop.model.user.application.Application;
import com.teamdev.jsnoop.model.user.application.UserShareInfo;
import com.teamdev.jsnoop.service.DomainConfiguration;
import com.teamdev.jsnoop.service.mail.MailSender;
import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapper;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.StringWriter;
import java.util.*;

import static org.springframework.data.mongodb.core.query.Criteria.where;

/**
 * Author: Alexander Serebriyan
 * Date: 18.05.12
 */
@Service
public class ApplicationService {

    // mongo operations object
    private final MongoTemplate mongoTemplate;
    private final UserRepository userRepository;
    private final KeyRepository keyRepository;


    @Autowired
    public ApplicationService(UserRepository userRepository,
                              MongoTemplate mongoTemplate,
                              KeyRepository keyRepository) {
        this.userRepository = userRepository;
        this.mongoTemplate = mongoTemplate;
        this.keyRepository = keyRepository;
    }


    /**
     * Add application to the user`s app list
     *
     * @param userId user`s id
     * @param app    application to add
     * @return saved application
     */
    public Application saveApp(final String userId, final Application app) {
        // if user already has app with such name then skip
        if (appExists(userId, app.getName())) {
            return null;
        }
        User user = mongoTemplate.findOne(new Query(Criteria.where("userId").is(userId)), User.class);
        String mail = user.getEmail();
        app.setOwnerUser(mail);
        String trash = String.valueOf(Calendar.getInstance().getTimeInMillis()) + userId;
        String newAppId = new Md5PasswordEncoder().encodePassword(app.getName() + trash, null);
        app.setAppId(newAppId);
        // save app to the database
        mongoTemplate.updateFirst(
                new Query(Criteria.where("userId").is(userId)),
                new Update().addToSet("applications", app),
                User.class);
        return app;
    }


    /**
     * Remove application with specified id from user's app list
     *
     * @param appId application`s id
     */
    public void removeApp(final String appId) {
        mongoTemplate.updateFirst(
                new Query(Criteria.where("applications.appId").is(appId)),
                new Update().pull("applications", new BasicDBObject("appId", appId)),
                User.class);
    }

    /**
     * Updates application of specified user
     *
     * @param appId id of application that must be updated
     */
    public Application updateApp(final String userId, final String appId, final String newName) {
        if (appExists(userId, newName)) {
            return null;
        }

        mongoTemplate.updateFirst(
                new Query(Criteria.where("applications.appId").is(appId)),
                new Update().set("applications.$.name", newName),
                User.class);
        return new Application(newName, appId);
    }

    /**
     * Check if user with specified id has app with specified name
     *
     * @param userId  id of user
     * @param appName application`s name
     * @return true if does
     */
    public boolean appExists(final String userId, final String appName) {
        return mongoTemplate.findOne(new Query(Criteria.where("userId").is(userId).and("applications.name").is(appName)), User.class) != null;
    }

    /**
     * Find application by its id and owner`s id
     *
     * @param appId application`s id
     * @return
     */
    public Application findApp(final String appId) {

        // find user
        User user = mongoTemplate.findOne(new Query(Criteria.where("applications.appId").is(appId)), User.class);
        Application searchedApp = null;

        // check if he has such application
        for (Application app : user.getApps()) {
            if (appId.equals(app.getAppId())) {
                searchedApp = app;
            }
        }
        return searchedApp;
    }

    /**
     * Get all user`s applications
     *
     * @param userId user`s id
     * @return list of user`s applications
     */
    public List<Application> listApplications(final String userId) {
        User user = mongoTemplate.findOne(new Query(Criteria.where("userId").is(userId)), User.class);
        return getAllApplicationsUser(user);
    }


    /**
     * Returns access type granted to user for this application
     *
     * @param userId user id
     * @param appId  application id
     * @return AccessType.FULL for full access, AccessType.READ for readonly access, AccessType.DENIED if user has no access to this application
     */
    private AccessType getUserAccessForApp(final String userId, final String appId) {
        User userToCheck = mongoTemplate.findOne(new Query(where("userId").is(userId)), User.class);
        User owner = mongoTemplate.findOne(new Query(where("applications.appId").is(appId)), User.class);

        // if user to check and application`s owner are the same
        if (owner.getUserId().equals(userId)) {
            return AccessType.FULL;
        }

        Application app = null;
        for (Application appl : owner.getApps()) {
            if (appId.equals(appl.getAppId())) {
                app = appl;
                break;
            }
        }

        assert app != null;

        AccessType accessType = AccessType.DENIED;

        for (UserShareInfo shareInfo : app.getShareInfo().getUsers()) {
            if (shareInfo.getEmail().equals(userToCheck.getEmail())) {
                accessType = shareInfo.getAccess();
                break;
            }
        }

        return accessType;
    }

    /**
     * Check if user have full access to this application
     *
     * @param userId user id
     * @param appId  application id
     * @return true if user granted with full access, false otherwise
     */
    public boolean userHaveFullAccess(final String userId, final String appId) {
        return getUserAccessForApp(userId, appId) == AccessType.FULL;
    }

    /**
     * Check if user have read access to this application
     *
     * @param userId user id
     * @param appId  application id
     * @return true if user granted with read or full access, false otherwise
     */
    public boolean userHaveReadAccess(final String userId, final String appId) {
        AccessType accessType = getUserAccessForApp(userId, appId);
        return accessType == AccessType.READ || accessType == AccessType.FULL;
    }

    /**
     * Share application with another user
     *
     * @param appId  app id to share
     * @param mail   email of user
     * @param access access type for the user
     * @param userId application owner id
     */
    public void shareApp(final String appId, final String mail, final String access, final String userId) {
        final Application app = findApp(appId);
        List<UserShareInfo> shareUsers = app.getShareInfo().getUsers();

        for (UserShareInfo shareUser : shareUsers) {
            if (shareUser.getEmail().equals(mail)) {
                return;
            }
        }

        User user = userRepository.findByEmail(mail);
        User adminUser = userRepository.findByUserId(userId);
        if (mail.equals(adminUser.getEmail())) {
            return;
        }

        Configuration config = new Configuration();
        config.setClassForTemplateLoading(ApplicationService.class, "/");
        config.setObjectWrapper(new DefaultObjectWrapper());
        Map<String, String> parameters = new HashMap<String, String>();
        parameters.put("mail", adminUser.getEmail());
        parameters.put("appName", app.getName());
        if (user == null) {
            String trash = String.valueOf(Calendar.getInstance().getTimeInMillis()) + userId;
            String key = new Md5PasswordEncoder().encodePassword(app.getName() + trash, null);
            String url = DomainConfiguration.getInstance().getHost() + "welcome/" + key;
            shareRegisterMail(url, config, parameters, mail);
            saveShareKey(adminUser.getEmail(), appId, key, access);
        } else {
            shareMail(config, parameters, mail);
            shareUserApp(mail, adminUser.getUserId(), access, app);
        }
    }


    private List<Application> getAllApplicationsUser(User user) {
        List<Application> allApps = new LinkedList<Application>();

        final List<User> users = mongoTemplate.findAll(User.class);

        List<Application> bufList = new LinkedList<Application>();
        allApps.addAll(user.getApps());
        for (User shareUser : users) {
            bufList.addAll(shareUser.getApps());
            for (Application app : bufList) {
                List<UserShareInfo> sharedUser = app.getShareInfo().getUsers();
                for (UserShareInfo concreteSharedUser : sharedUser) {
                    if (concreteSharedUser.getEmail().equals(user.getEmail())) {
                        allApps.add(app);
                    }
                }
            }
        }
        return allApps;
    }

    public boolean sharedWithNewUser(String shareKey, String mail) {
        Key key = mongoTemplate.findOne(new Query(Criteria.where("key").is(shareKey)), Key.class);
        if (key == null) {
            return false;
        } else {

            User user = mongoTemplate.findOne(new Query(Criteria.where("email").is(key.getAdminMail())), User.class);
            Application app = findApp(key.getAppId());
            if (!(user.getEmail() == mail)) {
                List<UserShareInfo> infoUsers = app.getShareInfo().getUsers();
                for (UserShareInfo infoUser : infoUsers) {
                    if (infoUser.getEmail() == mail) {
                        return true;
                    }
                }
            } else {
                return true;
            }
            UserShareInfo userShareInfo = new UserShareInfo();
            userShareInfo.setEmail(mail);
            userShareInfo.setAccess(key.getAccess());
            app.setShareUser(userShareInfo);
            mongoTemplate.updateFirst(
                    new Query(Criteria.where("email").is(key.getAdminMail()).and("applications.appId").is(key.getAppId())),
                    new Update().set("applications.$", app),
                    User.class);
            mongoTemplate.remove(new Query(Criteria.where("key").is(shareKey)), Key.class);
            return true;
        }
    }

    private void shareRegisterMail(final String url,
                                   Configuration config,
                                   Map<String, String> parameters,
                                   final String mail) {
        try {
            String subject = "Sharing Application";
            String SHARE_REGISTER_MAIL_PATH = "RegisterShareMail.ftl";
            MailSender mailSender = new MailSender();
            parameters.put("shareURL", url);
            Template template = config.getTemplate(SHARE_REGISTER_MAIL_PATH);
            StringWriter out = new StringWriter();
            template.process(parameters, out);
            mailSender.run(subject, out.getBuffer().toString(), mail);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (TemplateException e) {
            throw new RuntimeException(e);
        }


    }

    private void saveShareKey(final String adminUserMail,
                              final String appId,
                              final String key,
                              final String access) {
        Key shareKey = new Key();
        shareKey.setAdminMail(adminUserMail);
        shareKey.setAppId(appId);
        shareKey.setKey(key);
        AccessType accessType = AccessType.valueOf(access);
        shareKey.setAccess(accessType);
        mongoTemplate.save(shareKey);
    }


    private void shareMail(Configuration config,
                           Map<String, String> parameters,
                           final String mail) {
        try {
            String subject = "Sharing Application";
            String SHARE_MAIL_PATH = "ShareMail.ftl";
            MailSender mailSender = new MailSender();
            Template template = config.getTemplate(SHARE_MAIL_PATH);
            StringWriter out = new StringWriter();
            template.process(parameters, out);
            mailSender.run(subject, out.getBuffer().toString(), mail);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (TemplateException e) {
            throw new RuntimeException(e);
        }

    }

    private void shareUserApp(final String mail,
                              final String userId,
                              String access,
                              Application app) {
        UserShareInfo userShareInfo = new UserShareInfo();
        userShareInfo.setEmail(mail);
        userShareInfo.setAccess(AccessType.valueOf(access));
        app.setShareUser(userShareInfo);

        mongoTemplate.updateFirst(
                new Query(Criteria.where("userId").is(userId).and("applications.appId").is(app.getAppId())),
                new Update().set("applications.$", app),
                User.class);

    }


}
