package com.teamdev.jsnoop.service;

import com.teamdev.jsnoop.dao.UserRepository;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.security.authentication.encoding.PasswordEncoder;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.openid.OpenIDAttribute;
import org.springframework.security.openid.OpenIDAuthenticationToken;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;

/**
 * Author: Alexander Serebriyan
 * Date: 17.05.12
 */

@Service(value = "userAuthenticationService")
public class UserAuthenticationService implements AuthenticationUserDetailsService {

    private final static Logger LOG = Logger.getLogger(UserAuthenticationService.class);

    private final UserRepository userRepository;
    private final Collection<GrantedAuthority> DEFAULT_AUTHORITIES = AuthorityUtils.createAuthorityList("ROLE_USER");

    @Autowired
    public UserAuthenticationService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserDetails(Authentication token) throws UsernameNotFoundException {
        String email = getEmail((OpenIDAuthenticationToken) token);
        if (email != null) {
            if (!userExists(email)) {
                registerNewUser(email);
            }

            LOG.info("User with name " + email + " has logged in.");
            return new User(new Md5PasswordEncoder().encodePassword(email, null), "", DEFAULT_AUTHORITIES);
        }
        return null;
    }


    /**
     * Extract user`s email from the authentication token
     * @param token open id authentication token
     * @return user`s email
     */
    private String getEmail(OpenIDAuthenticationToken token) {
        String email = null;

        final OpenIDAuthenticationToken openIdToken = (OpenIDAuthenticationToken) token;
        final List<OpenIDAttribute> attributes = openIdToken.getAttributes();

        for (OpenIDAttribute attribute : attributes) {
            if ("email".equals(attribute.getName())) {
                email = attribute.getValues().get(0);
            }
        }
        return email;
    }

    /**
     * Check if user with given email already present in database
     *
     * @param email user`s email
     * @return true if user already registered
     */
    private boolean userExists(String email) {
        return userRepository.findByEmail(email) != null;
    }


    /**
     * Add new user record into database
     * @param email user`s email
     */
    private void registerNewUser(String email){
        PasswordEncoder encoder=new Md5PasswordEncoder();
        String userId = encoder.encodePassword(email, null);
        userRepository.save(new com.teamdev.jsnoop.model.user.User(userId, email));
    }
}
