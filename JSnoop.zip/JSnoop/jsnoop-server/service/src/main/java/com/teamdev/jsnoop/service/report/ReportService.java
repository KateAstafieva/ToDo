package com.teamdev.jsnoop.service.report;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.teamdev.jsnoop.dao.ReportRepository;
import com.teamdev.jsnoop.model.report.Report;
import com.teamdev.jsnoop.model.report.ReportType;
import com.teamdev.jsnoop.model.user.User;
import com.teamdev.jsnoop.model.user.application.Application;
import com.teamdev.jsnoop.service.application.ApplicationService;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.util.*;

import static org.springframework.data.mongodb.core.query.Criteria.where;

/**
 * Author: Alexander Serebriyan
 * Date: 29.05.12
 */
@Service
public class ReportService {


    private final static Logger LOG = Logger.getLogger(ReportService.class);
    private final MongoTemplate mongoTemplate;
    private final ApplicationService applicationService;
    private final ReportRepository reportRepository;


    @Autowired
    public ReportService(MongoTemplate mongoTemplate,
                         ApplicationService applicationService,
                         ReportRepository reportRepository) {
        this.mongoTemplate = mongoTemplate;
        this.applicationService = applicationService;
        this.reportRepository = reportRepository;
    }


    /**
     * Get report by it`s id
     *
     * @param id report`s id
     * @return Report with specified id
     */
    public Report getReport(String id) {
        return mongoTemplate.findOne(new Query(where("_id").is(id)), Report.class);
    }

    /**
     * Get reports for specified user`s application
     *
     * @param appId    application id
     * @param pageable pagination settings
     * @return reports page
     */
    public Page<Report> listReports(String appId, Pageable pageable) {
        return reportRepository.list(appId, pageable);
    }


    /**
     * Get reports for specified user`s application by their tags
     *
     * @param appId    application id
     * @param tags     tags to search by
     * @param pageable pagination settings
     * @return reports page
     */
    public Page<Report> listReports(String appId, List<String> tags, Pageable pageable) {
        return reportRepository.listByTags(appId, tags, pageable);
    }

    /**
     * Get reports for specified user`s application by their tags
     *
     * @param appId    application id
     * @param message  report message to search by
     * @param tags     tags to search by
     * @param pageable pagination settings
     * @return reports page
     */
    public Page<Report> listReports(String appId, String message, List<String> tags, Pageable pageable) {
        Page<Report> reports = reportRepository.listByTagsAndMessage(appId, message, tags, pageable);
        return reports;
    }


    /**
     * Find all tags for application`s reports
     *
     * @param appId application id
     * @return list of distinct tags
     */
    public List listTags(String appId) {
        List tags = mongoTemplate.getCollection("reports").distinct("tags", new BasicDBObject("appId", appId));
        return tags;
    }


    /**
     * Delete reports for specified application with specified tags and date range
     *
     * @param appId application id
     * @param from  start date of range
     * @param to    end date of range
     * @param tags  tag list
     */
    public void deleteReports(String appId, Long from, Long to, List<String> tags) {
        mongoTemplate.remove(new Query(where("appId").is(appId).and("tags").in(tags).and("date").gte(from).lte(to)), Report.class);
    }


    /**
     * Delete all reports for specified application
     *
     * @param appId application id
     */
    public void deleteAllReports(String appId) {
        mongoTemplate.remove(new Query(where("appId").is(appId)), Report.class);
    }


    public boolean reportsExists(String appId) {
        return mongoTemplate.getCollection("reports").count(new BasicDBObject("appId", appId)) > 0;
    }

    /**
     * Get json model for the reports chart in string representation
     *
     * @param appId list of application id`s
     * @return json model for client-side chart
     */
    public String getChartModel(String appId) {
        long date = -1l;

        return getChartModel(appId, date);

    }


    /**
     * Get json model for the reports chart in string representation
     *
     * @param appId list of application id`s
     * @return json model for client-side chart
     */
    public String getChartModel(String appId, long fromDate) {

        long start = Calendar.getInstance().getTimeInMillis();

        Map<ReportType, List<Report>> reports = new HashMap<ReportType, List<Report>>();

        for (ReportType type : ReportType.values()) {
            BasicDBObject queryObject;
            if (fromDate > 0) {
                queryObject = new BasicDBObject("appId", appId).append("type", type.name()).append("date", new BasicDBObject("$gte", fromDate));
            } else {
                queryObject = new BasicDBObject("appId", appId).append("type", type.name());
            }

            // for partial object fetching
            BasicDBObject keys = new BasicDBObject("date", 1);

            DBCursor cursor = mongoTemplate.getCollection("reports").find(queryObject, keys);

            List<Report> reps = new ArrayList<Report>();
            while (cursor.hasNext()) {
                Report report = new Report();
                report.setDate((long) ((Double) cursor.next().get("date")).doubleValue());
                reps.add(report);
            }

            if (reps.size() == 0){
                continue;
            }

            reports.put(type, reps);
        }

        LOG.info("getChartModel method execution time: " + (Calendar.getInstance().getTimeInMillis() - start) + " ms");

        return reports.size() > 0 ? createModel(reports, appId):getEmptyChartModel();
    }


    public String getEmptyChartModel() {
        return "{\"appId\":\"\", \"name\":\"\", \"details\":[]}";
    }


    /**
     * Create json model for chart on client-side using list of reports.
     *
     * @param reports list of reports
     * @return json model in string representation with next structure:
     *         <p/>
     *         [ { appId: "...", name: "...", details: [ {type: "...", data: [ { date: "...", reportsCount: "..."}, ... ]}, ...] }, ... ]
     */
    private String createModel(Map<ReportType, List<Report>> reports, String appId) {

        long start = Calendar.getInstance().getTimeInMillis();
        Map<String, Map<Long, Integer>> model = new TreeMap<String, Map<Long, Integer>>();


        for (ReportType reportType : reports.keySet()) {
            if (reports.get(reportType).size() < 1) {
                continue;
            }

            String type = reportType.name();
            for (Report report : reports.get(reportType)) {
                Date keyDate = new Date(report.getDate());
                Long timeStamp = DateUtils.round(keyDate, Calendar.SECOND).getTime();

                if (model.containsKey(type)) {
                    if (model.get(type).containsKey(timeStamp)) {
                        model.get(type).put(timeStamp, model.get(type).get(timeStamp) + 1);

                    } else {
                        model.get(type).put(timeStamp, 1);
                    }
                } else {
                    Map<Long, Integer> dataRecord = new TreeMap<Long, Integer>();
                    dataRecord.put(timeStamp, 1);
                    model.put(type, dataRecord);
                }
            }
        }

        LOG.info("createModel method execution time: " + (Calendar.getInstance().getTimeInMillis() - start) + " ms");
        return modelToJson(model, appId);
    }


    /**
     * Converts map with data for chart to json.  <p/>
     * Creates next output: [ { appId: "...", name: "...", details: [ {type: "...", data: [ { date: "...", reportsCount: "..."}, ... ]}, ...] }, ... ]
     *
     * @param model map with report data
     * @return data json representation
     */
    private String modelToJson(Map<String, Map<Long, Integer>> model, String appId) {
        long start = Calendar.getInstance().getTimeInMillis();

        StringBuilder response = new StringBuilder();


        String appName = applicationService.findApp(appId).getName();

        response.append("{\"appId\":\"");
        response.append(appId);
        response.append("\", \"name\":\"");
        response.append(appName);

        response.append("\", \"details\":[");

        for (String type : model.keySet()) {
            response.append("{\"type\":\"");
            response.append(type);
            response.append("\", \"data\":[");

            for (Long date : model.get(type).keySet()) {
                response.append("{ \"date\": \"");
                response.append(date);
                response.append("\", \"reportCounts\": \"");
                response.append(model.get(type).get(date));
                response.append("\"},");
            }

            if (response.charAt(response.length() - 1) != '[') {
                response.deleteCharAt(response.length() - 1);
            }
            response.append("]},");
        }

        if (response.charAt(response.length() - 1) != '[') {
            response.deleteCharAt(response.length() - 1);
        }

        response.append("]}");

        LOG.info("modelToJson method execution time: " + (Calendar.getInstance().getTimeInMillis() - start) + " ms");
        return response.toString();
    }

    public String getShareApplication(User user, String appId) {
        final List<User> users = mongoTemplate.findAll(User.class);
        List<Application> allApps = new LinkedList<Application>();
        List<Application> bufList = new LinkedList<Application>();
        Application bufApp = new Application();
        allApps.addAll(user.getApps());


        for (User shareUser : users) {
            bufList.addAll(shareUser.getApps());
            for (Application app : bufList) {
                if (appId.equals(app.getAppId())) {
                    return shareUser.getUserId();
                }
            }
        }
        return null;
    }

}
