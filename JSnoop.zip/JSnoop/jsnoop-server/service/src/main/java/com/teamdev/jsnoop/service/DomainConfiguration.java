package com.teamdev.jsnoop.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author Sergey Pensov
 */
public class DomainConfiguration {
    public static final String CONFIG_FILENAME = "domain.properties";
    public static final String HOST_KEY = "host";


    private static DomainConfiguration _instance;
    private String host;

    /**
     * Creates the configuration instance by parsing the appropriate configuration properties file.
     *
     * @throws java.io.IOException if the configuration file cannot be loaded.
     */
    private DomainConfiguration() throws IOException {
        final Properties properties = new Properties();
        InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(CONFIG_FILENAME);
        properties.load(is);
        host = properties.getProperty(HOST_KEY);


        if (host == null) {
            throw new IllegalStateException("Configuration is not fully defined: Host = " + host);
        }
    }

    /**
     * Creates the only instance of the configuration.
     *
     * @return instance of the configuration
     */
    public static synchronized DomainConfiguration getInstance() {
        if (_instance == null) {
            try {
                _instance = new DomainConfiguration();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return _instance;
    }

    public String getHost() {
        return host;
    }

}
