package com.teamdev.jsnoop.service.application;

import com.google.inject.internal.ImmutableSet;
import com.teamdev.jsnoop.model.report.Report;
import com.teamdev.jsnoop.model.report.ReportDetails;
import com.teamdev.jsnoop.model.user.User;
import com.teamdev.jsnoop.model.user.application.Application;
import com.teamdev.jsnoop.model.report.StackItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.util.*;

/**
 * Author: Alexander Serebriyan
 * Date: 29.05.12
 */
public class ApplicationListenerImpl implements ApplicationListener<ContextRefreshedEvent> {

    private final MongoTemplate mongoTemplate;

    @Autowired
    public ApplicationListenerImpl(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }


    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
        //fillReportsCollection();
    }

    private void generateReports(String userId, Application app) {

        for (int i = 0; i < 50; i++) {

            List<StackItem> stack = new ArrayList<StackItem>();

            for (int j = 0; j < 10; j++) {
                stack.add(new StackItem(j * 5, "http://somesite.com/somepath", "someFunction", new ArrayList<String>(ImmutableSet.of("<script type='text/javascript'>", "var breakme = function(){", "a.func.that.will.brea.k();"))));
            }

            ReportDetails details = new ReportDetails("onerror", "Some error message", stack);
            long date = generateDate();
            Report report = new Report(userId, app.getAppId(), "Some report message " + String.valueOf(i), ImmutableSet.of("tag 1", "tag 2", "tag 3"), details, date);
            mongoTemplate.save(report, "reports");
        }
    }

    private void fillReportsCollection() {
        final List<User> users = mongoTemplate.findAll(User.class);
        if (users == null) return;
        for (User user : users) {
            for (Application app : user.getApps()) {
                generateReports(user.getUserId(), app);
            }
        }
    }

    private long generateDate() {
        long range = 9000000000L;
        Random r = new Random();
        long shift = (long) (r.nextDouble() * range);

        Date now = Calendar.getInstance().getTime();
        return now.getTime() - shift;
    }

}
