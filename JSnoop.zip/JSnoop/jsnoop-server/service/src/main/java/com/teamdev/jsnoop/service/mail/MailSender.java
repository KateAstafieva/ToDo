package com.teamdev.jsnoop.service.mail;

import com.teamdev.jsnoop.model.user.application.Application;
import com.teamdev.jsnoop.model.user.application.UserShareInfo;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Properties;
import java.util.Set;

/**
 * @author sergey.pensov
 */

public class MailSender extends Thread {
    static final String ENCODING = "UTF-8";
    private final String SMTP_HOST = SmtpConfiguration.getInstance().getSmtpHost();
    private final String SMTP_PORT = SmtpConfiguration.getInstance().getSmtpPort();
    private final String MAIL_LOGIN = SmtpConfiguration.getInstance().getMailLogin();
    private final String PASSWORD = SmtpConfiguration.getInstance().getPassword();

    /**
     *
     * @param subject
     * @param content
     * @param address
     */
    public void run(String subject, String content, String address) {
        try {
            sendSimpleMessage(MAIL_LOGIN, PASSWORD, MAIL_LOGIN, address, content, subject, SMTP_PORT, SMTP_HOST);
        } catch (MessagingException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);

        }
    }

    /**
     *
     * @param subject
     * @param content
     * @param addresses
     */
    public void run(String subject, String content, Set<String> addresses) {
        try {
            for (String adres : addresses) {
                sendSimpleMessage(MAIL_LOGIN, PASSWORD, MAIL_LOGIN, adres, content, subject, SMTP_PORT, SMTP_HOST);
            }

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);

        }
    }

    /**
     *
     * @param activApplication
     */
    public void run(Application activApplication) {
        try {

            for (UserShareInfo shareInfo : activApplication.getShareInfo().getUsers()) {
                sendSimpleMessage(MAIL_LOGIN, PASSWORD, MAIL_LOGIN, shareInfo.getEmail(), "You have an abnormal report activity for " + activApplication.getName() + " application", "Report activity", SMTP_PORT, SMTP_HOST);
            }


        } catch (MessagingException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);

        }

    }

    public void sendSimpleMessage(String login, String password, String from, String to, String content, String subject, String smtpPort, String smtpHost)
            throws MessagingException, UnsupportedEncodingException {
        Authenticator auth = new MyAuthenticator(login, password);

        Properties props = System.getProperties();
        props.put("mail.smtp.port", smtpPort);
        props.put("mail.smtp.host", smtpHost);
        props.put("mail.smtp.auth", "true");
        props.put("mail.mime.charset", ENCODING);

        Session session = Session.getDefaultInstance(props, auth);

        Message msg = new MimeMessage(session);
        msg.setFrom(new InternetAddress(from));
        msg.setRecipient(Message.RecipientType.TO, new InternetAddress(to));
        msg.setSubject(subject);
        msg.setText(content);
        Transport.send(msg);
    }
}

class MyAuthenticator extends Authenticator {
    private String user;
    private String password;

    MyAuthenticator(String user, String password) {
        this.user = user;
        this.password = password;
    }

    public PasswordAuthentication getPasswordAuthentication() {
        String user = this.user;
        String password = this.password;
        return new PasswordAuthentication(user, password);
    }
}

