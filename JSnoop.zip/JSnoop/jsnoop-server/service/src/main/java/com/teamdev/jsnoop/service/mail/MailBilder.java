package com.teamdev.jsnoop.service.mail;

import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapper;
import freemarker.template.Template;
import freemarker.template.TemplateException;

import java.io.IOException;
import java.io.StringWriter;
import java.util.Map;

/**
 * @author Sergey Pensov
 */
public class MailBilder {


    public static synchronized String getMail(String fileName, Map<String, String> root) {
        Configuration config = new Configuration();
        config.setClassForTemplateLoading(MailBilder.class, "");
        config.setObjectWrapper(new DefaultObjectWrapper());



        try {
            Template template = config.getTemplate(fileName);
            StringWriter out = new StringWriter();
            template.process(root, out);
            System.out.println(out.getBuffer().toString());
            return out.getBuffer().toString();
        } catch (TemplateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

       return "fail";

    }

}
