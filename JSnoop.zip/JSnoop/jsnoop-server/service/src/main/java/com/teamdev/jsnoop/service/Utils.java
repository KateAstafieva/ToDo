package com.teamdev.jsnoop.service;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import org.springframework.data.domain.Page;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Author: Alexander Serebriyan
 * Date: 30.08.12
 */
public class Utils {

    /**
     * Extract tags array from json object that represented by string
     *
     * @param jsonObject String representation of json data
     * @return list of tags
     */
    public static List<String> extractArray(String jsonObject, String arrayName) {
        JsonParser parser = new JsonParser();

        // create json object from string representation
        JsonObject obj = parser.parse(jsonObject).getAsJsonObject();

        // get array field
        JsonArray array = obj.get(arrayName).getAsJsonArray();

        List<String> arrayItems = new ArrayList<String>();

        // populate list with data from array
        for (JsonElement arrayItem : array) {
            arrayItems.add(arrayItem.getAsString());
        }

        return arrayItems;
    }


    /**
     * Extracts value of the specified field from the json object
     *
     * @param jsonObject Json object in string representation
     * @param fieldName  name of the field to extract
     * @return value of the extracted filed
     */
    public static String extractField(String jsonObject, String fieldName) {
        JsonParser parser = new JsonParser();

        // create json object from string representation
        JsonObject filterData = parser.parse(jsonObject).getAsJsonObject();

        // get field value by name
        JsonElement value = filterData.get(fieldName);

        if (value == null || value.isJsonNull()) {
            return "";
        }

        String result = value.isJsonObject() ? value.getAsJsonObject().toString() : value.getAsString();
        return result;
    }

    /**
     * Translate spring.data page to the json object with some additional
     * fields for front-end table pagination (page, total, records).
     *
     * @param page page to translate
     * @return json object in string representation
     * @throws java.io.IOException
     */
    public static String pageToJson(Page page) throws IOException {
        JsonParser parser = new JsonParser();
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationConfig.Feature.WRITE_DATES_AS_TIMESTAMPS, false);

        // parse all rows as they are
        String contentString = mapper.writeValueAsString(page.getContent());
        JsonElement rows = parser.parse(contentString);


        // add some additional fields for client side pagination
        JsonObject jsonPage = new JsonObject();
        jsonPage.addProperty("page", String.valueOf(page.getNumber() + 1));
        jsonPage.addProperty("total", page.getTotalPages());
        jsonPage.addProperty("records", String.valueOf(page.getTotalElements()));
        jsonPage.add("rows", rows);

        return jsonPage.toString();
    }
}
