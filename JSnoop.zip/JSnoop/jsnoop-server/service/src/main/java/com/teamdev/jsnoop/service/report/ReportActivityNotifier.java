package com.teamdev.jsnoop.service.report;

import com.mongodb.BasicDBList;
import com.mongodb.DBObject;
import com.teamdev.jsnoop.model.report.Report;
import com.teamdev.jsnoop.model.user.User;
import com.teamdev.jsnoop.model.user.application.Application;
import com.teamdev.jsnoop.service.mail.MailSender;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.mapreduce.GroupBy;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import java.io.UnsupportedEncodingException;
import java.util.*;

/**
 * Author: Alexander Serebriyan
 * Date: 15.10.12
 */

@Service
public class ReportActivityNotifier {

    // contains info about already notified users
    // <userId, Set< appIds >>
    private Map<String, Set<String>> notified = new HashMap<String, Set<String>>();

    private final int REPORT_COUNT_THRESHOLD = 5000;

    private final MongoTemplate mongoTemplate;

    @Autowired
    public ReportActivityNotifier(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    /**
     * Notifies users in case of abnormal report activity
     */
    public void sendActivityNotifications() throws MessagingException, UnsupportedEncodingException {
        BasicDBList reportActivityDetails = getReportActivity();
        Map<String, Set<String>> usersToNotify = createRecipientList(reportActivityDetails);
        Map<User, Set<Application>> preparedData = prepareNotificationData(usersToNotify);
        sendEmailNotifications(preparedData);
    }


    /**
     * Creates list of users to send mail to.
     *
     * @param list List of next values: { userId: "...", appId: "...", count: "..."}
     * @return Map of user ids that should receive notification and ids of applications
     *         that have abnormal reports activity.
     *         <p> Map&lt;userId, Set&lt;appId&gt;&gt; <p/>
     */
    private Map<String, Set<String>> createRecipientList(BasicDBList list) {
        Map<String, Set<String>> usersToNotify = new HashMap<String, Set<String>>();

        for (Object obj : list) {
            DBObject object = (DBObject) obj;
            Double count = (Double) object.get("count");
            String appId = (String) object.get("appId");
            String userId = (String) object.get("userId");

            // if report count for this application greater then threshold value and user was not
            // notified yet then add user to the recipient list
            if (count > REPORT_COUNT_THRESHOLD) {

                // user hasn't been notified yet
                if ((!notified.containsKey(userId) && !usersToNotify.containsKey(userId)) || (notified.containsKey(userId) && !notified.get(userId).contains(appId))) {
                    Set<String> appsSet = new HashSet<String>();
                    appsSet.add(appId);
                    usersToNotify.put(userId, appsSet);
                } else if (usersToNotify.containsKey(userId) && !usersToNotify.get(userId).contains(appId)) {
                    usersToNotify.get(userId).add(appId);
                }
            }
        }

        // store already notified users
        notified.putAll(usersToNotify);

        return usersToNotify;
    }


    /**
     * Replace user ids with emails and application ids with names;
     *
     * @param usersToNotify Map of user ids that should receive notification and ids of applications
     *                      that have abnormal reports activity.
     *                      <p> Map&lt;userId, Set&lt;appId&gt;&gt; <p/>
     * @return Map with user emails and application names
     *         <p> Map&lt;user, Set&lt;application&gt;&gt; </p>
     */
    private Map<User, Set<Application>> prepareNotificationData(Map<String, Set<String>> usersToNotify) {
        List<User> users = mongoTemplate.find(new Query(Criteria.where("userId").in(usersToNotify.keySet())), User.class);
        Map<User, Set<Application>> recipientsInfo = new HashMap<User, Set<Application>>();

        for (User user : users) {

            // replace application ids with names
            Set<String> apps = usersToNotify.get(user.getUserId());
            Set<Application> applications = new HashSet<Application>();

            for (Application app : user.getApps()) {
                if (apps.contains(app.getAppId())) {
                    applications.add(app);
                }
            }

            // replace user id with user email
            recipientsInfo.put(user, applications);
        }

        return recipientsInfo;
    }

    /**
     * Gets beginning of the current day
     *
     * @return 00:00 time of the current day as ling value
     */
    private long getInitialTime() {
        long oneDay = 86400000l;

        Date now = Calendar.getInstance().getTime();
        long targetTime = DateUtils.ceiling(now, Calendar.DAY_OF_MONTH).getTime() - oneDay;
        return targetTime;
    }

    /**
     * Gets info about reports activity.
     *
     * @return List of objects with next structure:
     *         { userId: "...", appId: "...", count: "..."}
     */
    private BasicDBList getReportActivity() {

        // get info about reports created after this date
        long initTime = getInitialTime();

        String initial = "{count: 0}";
        String reduce = "function(obj, prev){ prev.count++; }";
        GroupBy groupBy = GroupBy.key("userId", "appId", "type").initialDocument(initial).reduceFunction(reduce);
        Criteria criteria = Criteria.where("date").gt(initTime);

        Map resultMap = mongoTemplate.group(criteria, "reports", groupBy, Report.class).getRawResults().toMap();
        return (BasicDBList) resultMap.get("retval");
    }


    /**
     * Send email notifications on each application that has abnormal report activity
     *
     * @param recipientsInfo Map with users and applications that has abnormal activity
     * @throws MessagingException
     * @throws UnsupportedEncodingException
     */
    private void sendEmailNotifications(Map<User, Set<Application>> recipientsInfo) throws MessagingException, UnsupportedEncodingException {
        for (User user : recipientsInfo.keySet()) {
            MailSender mailSender = new MailSender();
            for (Application app : recipientsInfo.get(user)) {
                mailSender.run(app);
            }
        }
    }


    /**
     * Clear list of already notified users
     */
    public void resetNotifiedUsersList() {
        notified.clear();
    }

}
