package com.teamdev.jsnoop.service.mail;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created with IntelliJ IDEA.
 * User: bot
 * Date: 04.09.12
 * Time: 17:25
 * To change this template use File | Settings | File Templates.
 */
public class SmtpConfiguration {

    public static final String CONFIG_FILENAME = "smtp-server.properties";
    public static final String HOST_KEY = "smtpHost";
    public static final String PORT_KEY = "smtpPort";
    public static final String MAIL_KEY = "mailLogin";
    public static final String PASSWORD_KEY = "password";

    private static SmtpConfiguration _instance;
    private String smtpHost;
    private String smtpPort;
    private String mailLogin;
    private String password;

    /**
     * Creates the configuration instance by parsing the appropriate configuration properties file.
     *
     * @throws java.io.IOException if the configuration file cannot be loaded.
     */
    private SmtpConfiguration() throws IOException {
        final Properties properties = new Properties();
        InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(CONFIG_FILENAME);
        properties.load(is);
        smtpHost = properties.getProperty(HOST_KEY);
        smtpPort = properties.getProperty(PORT_KEY);
        mailLogin = properties.getProperty(MAIL_KEY);
        password = properties.getProperty(PASSWORD_KEY);

        if (smtpHost == null || smtpPort == null || mailLogin == null || password == null) {
            throw new IllegalStateException("Configuration is not fully defined: smtpHost = " + smtpHost
                    + "; smtpPort = " + smtpPort
                    + "; mailLogin = " + mailLogin
                    + "; password = " + password);
        }
    }

    /**
     * Creates the only instance of the configuration.
     *
     * @return instance of the configuration
     */
    public static synchronized SmtpConfiguration getInstance() {
        if (_instance == null) {
            try {
                _instance = new SmtpConfiguration();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return _instance;
    }

    public String getSmtpHost() {
        return smtpHost;
    }

    public String getSmtpPort() {
        return smtpPort;
    }

    public String getPassword() {
        return password;
    }

    public String getMailLogin() {
        return mailLogin;
    }

}
