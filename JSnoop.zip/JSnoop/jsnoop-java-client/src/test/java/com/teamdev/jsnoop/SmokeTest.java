package com.teamdev.jsnoop;

import org.apache.log4j.PropertyConfigurator;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

/**
 * Asynchronous client class test
 *
 * @author sergey.pensov
 */
public class SmokeTest {

    //@Ignore
    @Test
    public void testSendingSimpleRequest() throws InterruptedException {
        Logger.setSender(new MockRequest());
        SendLogStream one = new SendLogStream("one");
        one.t.start();
        SendLogStream two = new SendLogStream("two");
        two.t.start();
        SendLogStream three = new SendLogStream("three");
        three.t.start();
        two.t.join();
        three.t.join();
        one.t.join();
        Assert.assertNotNull("bad API", MockRequest.logs);

    }

    @Test
    @Ignore
    public void testSendingRequest() throws InterruptedException {
        SendLogStream one = new SendLogStream("one");
        one.t.start();
        one.t.join();
    }

    @Test
    @Ignore
    public void testLog4JAppender() throws InterruptedException {
        org.apache.log4j.Logger log4jLogger = org.apache.log4j.Logger.getLogger("Log4JTest");
        PropertyConfigurator.configure(SmokeTest.class.getResource("log4j.properties"));
        log4jLogger.error("Test Log4J message");
    }

}
