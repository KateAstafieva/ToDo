package com.teamdev.jsnoop;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

/**
 * @author sergey.pensov
 */
public class SendLogStream implements Runnable {
    public static List<List<String>> messages = new LinkedList<List<String>>();
    private String name = new String();
    Thread t;

    SendLogStream(String name) {
        t = new Thread(this);
        this.name = name;
    }

    /**
     *
     */
    public void run() {
        Random r = new Random();

        int period = 0;
        while (period < 600) {
            for (int i = 0; i < r.nextInt(500); i++) {
                Logger.log("message " + Integer.toString(i), name, Integer.toString(period));
                messages.add(addLog("message " + Integer.toString(i), name, Integer.toString(period)));
            }
            try {
                t.sleep(1000);
            } catch (InterruptedException e) {
                Logger.log("bugs " + name);
            }
            ++period;
        }
    }

    /**
     *
     * @param message
     * @param tags
     * @return
     */
    private synchronized List<String> addLog(String message, String... tags) {
        List<String> log = new LinkedList<String>();
        String info = new String();
        info = "[\"";
        for (String tag : tags) {
            info = info + tag + "\",\"";
        }
        info = info.substring(0, info.length() - 3);
        info = info + "\"]";
        log.add(message);
        log.add(info);
        return log;
    }
}
