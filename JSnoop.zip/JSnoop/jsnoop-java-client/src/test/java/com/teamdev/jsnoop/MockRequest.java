package com.teamdev.jsnoop;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

/**
 * Simulates a request
 *
 * @author sergey.pensov
 */
public class MockRequest implements RequestSender {
    public static List<List<Object>> logs = new LinkedList<List<Object>>();

    @Override
    public synchronized void request(String jsonObjectString) throws IOException {
        try {

            parse(jsonObjectString);
        } catch (ParseException e) {

        }
    }

    /**
     * Parses a JsonString
     * @param jsonText - JsonString
     * @throws ParseException - error while parsing
     */
    public synchronized void parse(String jsonText) throws ParseException {
        JSONParser parser = new JSONParser();
        Object rawObject = parser.parse(jsonText);
        JSONObject outsideJsonObject = (JSONObject) rawObject;
        List<JSONObject> jsonArray = (List<JSONObject>) outsideJsonObject.get(PackageBuilder.REPORTS);

        for (JSONObject insideJsonObject : jsonArray) {

            List<Object> log = new LinkedList<Object>();
            JSONObject infoObject = (JSONObject) insideJsonObject.get(PackageBuilder.INFO);
            String message = (String) infoObject.get(PackageBuilder.MESSAGE);
            log.add(message);

            JSONArray tags = (JSONArray) insideJsonObject.get(PackageBuilder.TAGS);
            log.add(tags);


            logs.add(log);
        }

    }


}
