package com.teamdev.jsnoop.extensions;

import com.teamdev.jsnoop.Logger;
import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.spi.LoggingEvent;

/**
 * Author: Andrew.Palval@teamdev.com
 */
public class Log4JSnoopAppender extends AppenderSkeleton {
    @Override
    protected void append(LoggingEvent event) {
        Logger.log(event.getMessage().toString(), event.getLevel().toString(), event.getLoggerName());
    }

    @Override
    public void close() {
        this.closed = true;
    }

    @Override
    public boolean requiresLayout() {
        return false;
    }
}
