package com.teamdev.jsnoop;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author sergey.pensov
 */
public class PackageBuilder {

    private final static String userId = Configuration.getInstance().getUserId();
    private final static String appId = Configuration.getInstance().getAppId();
    public final static String TAGS = "tags";
    public final static String INFO = "details";
    public final static String MESSAGE = "message";
    public final static String DATE = "date";
    public final static String REPORTS = "reports";
    public final static String USERID = "userId";
    public final static String APPID = "appId";
    public final static String TYPE = "type";


    private static AtomicBoolean noBuf = new AtomicBoolean(false);
    private static AtomicBoolean isHavePackage = new AtomicBoolean(false);
    private static List<JSONObject> bufJsonArray = new LinkedList<JSONObject>();
    private static List<JSONObject> jsonArray = new LinkedList<JSONObject>();
    private static JSONObject outsideJsonObject = new JSONObject();

    private static Random random = new Random();

    /**
     * Builds the package request
     *
     * @param message reveals the essence of the problem
     * @param tags    tags of the message
     */
    public static synchronized void addMessage(String message, String... tags) {
        JSONArray jsonArrayTags = new JSONArray();
        for (int i=0;i<tags.length;i++){
           jsonArrayTags.add(tags[i]);
        }

        final JSONObject insideJsonObject = new JSONObject();
        long time = System.currentTimeMillis();
        insideJsonObject.put(TAGS,jsonArrayTags);
        final JSONObject infoObject = new JSONObject();
        insideJsonObject.put(INFO, infoObject);
        infoObject.put(MESSAGE, message);
        insideJsonObject.put(DATE, time);

        String type = random.nextInt(2) > 0 ? "JS":"JAVA";

        insideJsonObject.put(TYPE, type);
        if (noBuf.get()) {
            bufJsonArray.add(insideJsonObject);
        } else {
            jsonArray.add(insideJsonObject);
        }

        isHavePackage.set(true);
    }

    /**
     * Builds the JSON request
     *
     * @return JSON request
     */
    public static synchronized String getJsonString() {

        outsideJsonObject.put(USERID, userId);
        outsideJsonObject.put(APPID, appId);
        outsideJsonObject.put(REPORTS, jsonArray);
        isHavePackage.set(false);

        return convertToString(outsideJsonObject);
    }

    /**
     * Clear package
     */
    public static synchronized void clearMessages() {
        outsideJsonObject.clear();

        jsonArray.clear();
        if (bufJsonArray.size() > 0) {
            jsonArray.addAll(bufJsonArray);
            bufJsonArray.clear();
        }
    }


    public static synchronized boolean hasMessages() {
        return jsonArray.size() > 0;
    }

    /**
     * Converts JSONObject to a string
     *
     * @param jsonObject-convertible object
     * @return Json string
     */
    public static String convertToString(JSONObject jsonObject) {
        final StringWriter jsonio = new StringWriter();
        final String jsonText;

        try {
            jsonObject.writeJSONString(jsonio);
        } catch (IOException e) {

        }

        jsonText = jsonio.toString();
        return jsonText;
    }

    public static void setNoBuf(boolean value) {
        noBuf.set(value);
    }
}
