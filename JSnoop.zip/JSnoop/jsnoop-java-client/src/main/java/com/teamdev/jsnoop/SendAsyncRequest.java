package com.teamdev.jsnoop;

import com.ning.http.client.AsyncCompletionHandler;
import com.ning.http.client.AsyncHttpClient;
import com.ning.http.client.Response;

import java.io.IOException;

/**
 * Creates and sends a request to server.
 *
 * @author sergey.pensov
 */
public class SendAsyncRequest implements RequestSender {
    @Override
    /**
     *Sends a request to server
     */
    public void request(String jsonObjectString) throws IOException {
        final AsyncHttpClient c = new AsyncHttpClient();
        final String serverUrl = Configuration.getInstance().getServerUrl();

        c.preparePost(serverUrl)
                .setBody(jsonObjectString).setHeader("Content-Type", "application/json")
                .execute(new AsyncCompletionHandler<String>() {

                    @Override
                    public String onCompleted(Response response) throws Exception {
                        // Do something with the Response
                        return response.getStatusText();
                    }

                    @Override
                    public void onThrowable(Throwable t) {
                        // Something wrong happened.
                        throw new RuntimeException(t);
                    }
                });
        System.out.println(jsonObjectString);
    }


}






