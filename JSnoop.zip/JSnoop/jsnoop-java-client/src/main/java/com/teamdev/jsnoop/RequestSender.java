package com.teamdev.jsnoop;

import org.json.simple.JSONObject;

import java.io.IOException;
import java.util.LinkedList;

/**
 * @author sergey.pensov
 */
public interface RequestSender {


    public void request(String jsonObjectString) throws IOException;

}
