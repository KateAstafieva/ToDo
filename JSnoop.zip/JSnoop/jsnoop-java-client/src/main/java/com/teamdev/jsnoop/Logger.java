package com.teamdev.jsnoop;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Defines the API for logging.
 *
 * @author sergey.pensov
 */

public class Logger {

    private static  AtomicBoolean hookSetUp = new AtomicBoolean(true);
    private static TimerStream hooktimer;
    private static RequestSender sender;
    private static  AtomicBoolean haveSender = new AtomicBoolean(false);

    /**
     * Send sends a message to the class PackageBuilder,put hook and starts the timer again, if it is turned off
     *
     * @param message reveals the essence of the problem
     * @param tags    tags of the message
     */
    public synchronized static void log(String message, String... tags) {
        TimerStream timerStream;
        //  System.out.println(Arrays.toString(tags));
        PackageBuilder.addMessage(message, tags);
        if (TimerStream.getIsTimerStop().get()) {
            if (haveSender.get()){
                  timerStream = new TimerStream(sender);
            } else{
                 timerStream = new TimerStream();
            }

            timerStream.start();
        }
        start();
    }

    /**
     * Put the hook if before he was not raised
     */
    private static synchronized void start() {
        if (hookSetUp.get()) {
            hooktimer = new TimerStream();
            if (haveSender.get()){
                hooktimer = new TimerStream(sender);
            } else{
                hooktimer = new TimerStream();
            }
            Runtime.getRuntime().addShutdownHook(hooktimer);
            hookSetUp.set(false);
        }
    }

    /**
     *Redirects requests to the test
     * @param testSender - object implementing interface RequestSender
     */
    public static void  setSender(RequestSender testSender){
         sender = testSender;
         haveSender.set(true);
    }

}
