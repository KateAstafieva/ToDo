package com.teamdev.jsnoop;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Defines the configuration for the client.
 *
 * @author sergey.pensov
 */
public class Configuration {

    public static final String CONFIG_FILENAME = "jsnoop-client.properties";
    public static final String SERVER_URL_KEY = "server.url";
    public static final String USER_ID_KEY = "userId";
    public static final String APP_ID_KEY = "appId";

    private static Configuration _instance;
    private String serverUrl;
    private String userId;
    private String appId;

    /**
     * Creates the configuration instance by parsing the appropriate configuration properties file.
     *
     * @throws IOException if the configuration file cannot be loaded.
     */
    private Configuration() throws IOException {
        final Properties properties = new Properties();
        InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(CONFIG_FILENAME);
        properties.load(is);
        serverUrl = properties.getProperty(SERVER_URL_KEY);
        userId = properties.getProperty(USER_ID_KEY);
        appId = properties.getProperty(APP_ID_KEY);

        if (serverUrl == null || userId == null || appId == null) {
            throw new IllegalStateException("Configuration is not fully defined: User ID = " + userId
                    + "; App ID = " + appId
                    + "; Server URL = " + serverUrl);
        }
    }

    /**
     * Creates the only instance of the configuration.
     *
     * @return instance of the configuration
     */
    public static synchronized Configuration getInstance() {
        if (_instance == null) {
            try {
                _instance = new Configuration();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return _instance;
    }

    public String getServerUrl() {
        return serverUrl;
    }

    public String getUserId() {
        return userId;
    }

    public String getAppId() {
        return appId;
    }
}
