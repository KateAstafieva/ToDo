package com.teamdev.jsnoop;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author sergey.pensov
 */
public class TimerStream extends Thread {


    public static AtomicBoolean isTimerStop = new AtomicBoolean(true);

    private RequestSender sender = new SendAsyncRequest();

    /*in package */TimerStream() {
        isTimerStop.set(false);
    }

    /**
     *
     * @param sender - Class that simulates a request
     */
    /*in package */TimerStream(RequestSender sender) {
        this.sender = sender;
        isTimerStop.set(false);
    }

    /**
     * Starts a thread that sends the request a second later
     */
    public synchronized void run() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {

        }
        PackageBuilder.setNoBuf(true);
        if (PackageBuilder.hasMessages()) {

            try {
                sender.request(PackageBuilder.getJsonString());

            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        isTimerStop.set(true);
        PackageBuilder.setNoBuf(false);
        PackageBuilder.clearMessages();

    }

    public synchronized static AtomicBoolean getIsTimerStop() {
        return isTimerStop;
    }

    /**
     * Compares the hashCode of the two objects
     *
     * @param o object to compare
     * @return true or false
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TimerStream that = (TimerStream) o;

        if (sender != null ? !sender.equals(that.sender) : that.sender != null)
            return false;

        return true;
    }

    /**
     * return hashCode AsyncRequest
     *
     * @return return hashCode AsyncRequest
     */
    @Override
    public int hashCode() {
        return sender != null ? sender.hashCode() : 0;
    }

    /* package*/ void setSender(RequestSender sender) {
        this.sender = sender;
    }
}
