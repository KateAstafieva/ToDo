var app = app || {};

(function() {
    'use strict';

    // Exercise Model
    // ----------

    app.Exercise = Backbone.Model.extend({
        defaults: {
            title: '',
            description: '',
            completed: false
        },

        // Toggle the `completed` state of this exercise item.
        toggle: function() {
            this.save({
                completed: !this.get('completed')
            });
        }

    });

}());