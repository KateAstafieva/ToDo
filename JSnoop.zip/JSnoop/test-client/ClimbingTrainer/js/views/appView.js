var app = app || {};

$(function( $ ) {
    'use strict';

    // The Application
    // ---------------

    // Our overall **AppView** is the top-level piece of UI.
    app.AppView = Backbone.View.extend({

        // Instead of generating a new element, bind to the existing skeleton of
        // the App already present in the HTML.
        el: '#climbingApp',

        // Our template for the line of statistics at the bottom of the app.
        statsTemplate: _.template( $('#stats-template').html() ),

        // At initialization we bind to the relevant events on the `Todos`
        // collection, when items are added or changed. Kick things off by
        // loading any preexisting todos that might be saved in *localStorage*.
        initialize: function() {
            this.$sidebar = this.$('#sidebar');

            app.Training.on('change:completed', this.filterOne, this);
            app.Training.on('add', this.addOne, this);

            this.render();

            app.Training.add([
                {title: "Jump",
                description: "Do jump as long as you can"}
            ]);
        },

        // Re-rendering the App just means refreshing the statistics -- the rest
        // of the app doesn't change.
        render: function() {
            this.$sidebar.html(this.statsTemplate());
        },


        filterOne : function (ex) {
            ex.trigger("visible");
        },

        // Add a single todo item to the list by creating a view for it, and
        // appending its element to the `<ul>`.
        addOne: function( todo ) {
            var view = new app.ExView({ model: todo });
            $('#content').append( view.render().el );
        }

    });
});
