var app = app || {};

$(function( $ ) {
    'use strict';

    // Exercise Item View
    // --------------

    // The DOM element for a exercise item...
    app.ExView = Backbone.View.extend({

        // Cache the template function for a single item.
        template: _.template( $('#item-template').html() ),

        initialize: function() {

        },

        // Re-render the titles of the todo item.
        render: function() {
            this.$el.html( this.template( this.model.toJSON() ) );
      /*      this.$el.toggleClass( 'completed', this.model.get('completed') );

            this.toggleVisible();
            this.input = this.$('.edit');*/
            return this;
        },

        // The DOM events specific to an item.
        events: {
            'click .toggle':	'togglecompleted'
        },

        // Toggle the `"completed"` state of the model.
        togglecompleted: function() {
            console.log("---------Click---------");
            this.model.toggle();
        }
    });
});
