var app = app || {};

(function() {
    'use strict';

    // Training Collection
    // ---------------

    // The collection of todos is backed by *localStorage* instead of a remote
    // server.
    var Training = Backbone.Collection.extend({

        // Reference to this collection's model.
        model: app.Exercise,

        // Save all of the todo items under the `"todos"` namespace.
        localStorage: new Store('training-backbone')
    });

    // Create our global collection of **Exercises**.
    app.Training = new Training();
}());
