var Controller = Backbone.Router.extend({
    routes: {
        "!/done": "toggle"
    },

    toggle: function () {
        $(".block").hide();
        $("#start").show();
    }
});

var controller = new Controller();

Backbone.history.start();