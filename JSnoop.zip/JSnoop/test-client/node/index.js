var server = require("./server");
var express = require("express");
server.start();